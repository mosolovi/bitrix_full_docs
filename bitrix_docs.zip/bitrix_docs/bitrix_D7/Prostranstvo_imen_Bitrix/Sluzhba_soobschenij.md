[Пространство имён Bitrix](/api_d7/bitrix/index.php)

Служба сообщений

* [Провайдеры](/api_d7/bitrix/messageservice/smsmanager.php)
* [Отправка сообщения](/api_d7/bitrix/messageservice/send/index.php)
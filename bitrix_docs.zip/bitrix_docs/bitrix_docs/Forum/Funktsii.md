[Форум](/api_help/forum/index.php)

[Функции](/api_help/forum/functions/index.php)

Функции для использования в публичной части (доступно с 3.3.3)

Функции для использования в публичной части
===========================================

Эти функции уже содержат проверки на права и корректность входных параметров, поэтому для выполнения необходимого действия достаточно просто вызвать соответствующую функцию.

| Функция | Описание |
| --- | --- |
| [ForumCurrUserPermissions](/api_help/forum/functions/forumcurruserpermissions.php) | Возвращает права текущего посетителя на доступ к форуму. |
| [ForumSubscribeNewMessages](/api_help/forum/functions/forumsubscribenewmessages.php) | Подписка текущего пользователя на новые сообщения заданной темы. |
| [ForumAddMessage](/api_help/forum/functions/forumaddmessage.php) | Добавление и изменение нового сообщения и темы. |
| [ForumModerateMessage](/api_help/forum/functions/forummoderatemessage.php) | Публикация и скрытие сообщения. |

Новинки документации в соцсетях:
[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumSmile](/api_help/forum/developer/cforumsmile/index.php)

Delete (доступен с 3.3.3)

Delete
======

```
bool
Delete(
	int ID
);Копировать
```

Удаляет смайл с кодом *ID*. Метод статический.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| ID | Код смайла, который необходимо удалить. |

#### Возвращаемое значение

Возвращает True в случае успешного удаления, в противном случае возвращает False.

Новинки документации в соцсетях:
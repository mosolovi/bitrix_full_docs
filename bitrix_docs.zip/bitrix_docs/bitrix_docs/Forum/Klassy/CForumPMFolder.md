[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPMFolder](/api_help/forum/developer/cforumpmfolder/index.php)

Класс CForumPMFolder (доступен с 4.0.3)

Класс CForumPMFolder
====================

**CForumPMFolder** - класс для работы папками пользователя.

#### Методы класса

| Метод | Описание | C версии |
| --- | --- | --- |
| [Add](/api_help/forum/developer/cforumpmfolder/add.php) | Создание новой папки пользователя. | 4.0.3 |
| [Delete](/api_help/forum/developer/cforumpmfolder/delete.php) | Удаление папки пользователя. | 4.0.3 |
| [GetList](/api_help/forum/developer/cforumpmfolder/getlist.php) | Получение списка папок с возможностью фильтрации и сортировки. | 4.0.3 |
| [Update](/api_help/forum/developer/cforumpmfolder/update.php) | Изменение параметров папки пользователя. | 4.0.3 |

Новинки документации в соцсетях:
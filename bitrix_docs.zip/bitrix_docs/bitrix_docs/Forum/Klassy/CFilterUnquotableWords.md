[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CFilterUnquotableWords](/api_help/forum/developer/cfilterunquotablewords/index.php)

Класс CFilterUnquotableWords (доступен с 5.1.0)

Класс CFilterUnquotableWords
============================

**CFilterUnquotableWords** - класс для работы cо словарями слов.

#### Методы класса

| Метод | Описание | C версии |
| --- | --- | --- |
| [Add](/api_help/forum/developer/cfilterunquotablewords/add.php) | Создание новой записи. | 5.1.0 |
| [Delete](/api_help/forum/developer/cfilterunquotablewords/delete.php) | Удаление записи. | 5.1.0 |
| [GetList](/api_help/forum/developer/cfilterunquotablewords/getlist.php) | Получение списка записей с возможностью фильтрации и сортировки. | 5.1.0 |
| [Update](/api_help/forum/developer/cfilterunquotablewords/update.php) | Изменение параметров записи. | 5.1.0 |

Новинки документации в соцсетях:
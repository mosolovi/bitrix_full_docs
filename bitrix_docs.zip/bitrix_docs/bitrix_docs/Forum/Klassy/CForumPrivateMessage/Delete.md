[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPrivateMessage](/api_help/forum/developer/cforumprivatemessage/index.php)

Delete (доступен с 4.0.3)

Delete
======

```
bool
Delete(
	int ID
);Копировать
```

Удаляет сообщение с кодом *ID*. Метод статический.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| ID | Код сообщения, которое необходимо удалить. |

#### Возвращаемое значение

Возвращает True в случае успешного удаления, в противном случае возвращает False.

Новинки документации в соцсетях:
[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[textParser](/api_help/forum/developer/textparser/index.php)

Класс textParser (доступно с 3.0.2)

Класс textParser
================

**textParser** - класс, предназначенный для форматирования сообщений форума. Осуществляет замену спецсимволов и
заказных тегов на реальные HTML- теги, обработку ссылок, отображение смайлов.

#### Методы класса

| Метод | Описание | C версии |
| --- | --- | --- |
| [convert](/api_help/forum/developer/textparser/convert.php) | Функция форматирования сообщения. | 3.0.2 |

Новинки документации в соцсетях:
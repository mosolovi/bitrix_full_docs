[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPoints2Post](/api_help/forum/developer/cforumpoints2post/index.php)

Delete (доступен с 3.3.7)

Delete
======

```
bool
CForumPoints2Post::Delete(
	int ID
);Копировать
```

Удаляет запись с кодом ID из таблицы соответствий между количеством сообщений пользователя на форуме и количеством баллов за одно сообщение. Метод нестатический.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| ID | Код записи. |

#### Возвращаемые значения

Функция возвращает значение True.

Новинки документации в соцсетях:
[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CFilterUnquotableWords](/api_help/forum/developer/cfilterunquotablewords/index.php)

Delete (доступен с 5.1.0)

Delete
======

```
bool
Delete(
	int ID
);Копировать
```

Удаляет запись с кодом *ID*. Метод нестатический.

#### Параметры функции

| Параметр | Описание | C версии |
| --- | --- | --- |
| ID | Код записи, которую необходимо удалить. | 5.1.0 |

#### Возвращаемое значение

Возвращает True в случае успешного удаления, в противном случае возвращает False.

Новинки документации в соцсетях:
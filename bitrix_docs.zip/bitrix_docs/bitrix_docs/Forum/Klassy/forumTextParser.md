[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[forumTextParser](/api_help/forum/developer/forumtextparser/index.php)

Класс forumTextParser (доступно с 11.0.0)

Класс forumTextParser
=====================

**forumTextParser** - класс, предназначенный для форматирования сообщений форума. Этот класс - потомок класса TextParser, с расширениями для парсинга файлов и спойлеров. Осуществляет замену спецсимволов и заказных тегов на реальные HTML- теги, обработку ссылок, отображение смайлов.

#### Методы класса

| Метод | Описание | C версии |
| --- | --- | --- |
| [convert](/api_help/forum/developer/forumtextparser/convert.php) | Функция форматирования сообщения. | 11.0.0 |

Новинки документации в соцсетях:
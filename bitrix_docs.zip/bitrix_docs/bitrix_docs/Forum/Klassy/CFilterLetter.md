[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CFilterLetter](/api_help/forum/developer/cfilterletter/index.php)

Класс CFilterLetter (доступен с 5.1.0)

Класс CFilterLetter
===================

**CFilterLetter** - класс для работы cо словарями букв.

#### Методы класса

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/forum/developer/cfilterletter/add.php) | Создание новой записи. | 5.1.0 |
| [Delete](/api_help/forum/developer/cfilterletter/delete.php) | Удаление записи. | 5.1.0 |
| [GetList](/api_help/forum/developer/cfilterletter/getlist.php) | Получение списка записей с возможностью фильтрации и сортировки. | 5.1.0 |
| [Update](/api_help/forum/developer/cfilterletter/update.php) | Изменение параметров записи. | 5.1.0 |

Новинки документации в соцсетях:
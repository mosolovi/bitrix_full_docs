[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CFilterDictionary](/api_help/forum/developer/cfilterdictionary/index.php)

Delete (доступен с 5.1.0)

Delete
======

```
bool
CFilterDictionary::Delete(
	int ID
);Копировать
```

Удаляет папку с кодом *ID*. Метод нестатический.

#### Параметры

| Параметр | Описание | С версии |
| --- | --- | --- |
| ID | Код записи, которую необходимо удалить. |  |

#### Возвращаемое значение

Возвращает True в случае успешного удаления, в противном случае возвращает False.

Новинки документации в соцсетях:
[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CFilterDictionary](/api_help/forum/developer/cfilterdictionary/index.php)

Класс CFilterDictionary (доступен с 5.1.0)

Класс CFilterDictionary
=======================

**CFilterDictionary** - класс для работы cо словарями нецензурных слов.

#### Методы класса

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/forum/developer/cfilterdictionary/add.php) | Создание нового словаря. | 5.1.0 |
| [Delete](/api_help/forum/developer/cfilterdictionary/delete.php) | Удаление словаря. | 5.1.0 |
| [GetList](/api_help/forum/developer/cfilterdictionary/getlist.php) | Получение списка словарей с возможностью фильтрации и сортировки. | 5.1.0 |
| [Update](/api_help/forum/developer/cfilterdictionary/update.php) | Изменение параметров словаря. | 5.1.0 |

Новинки документации в соцсетях:
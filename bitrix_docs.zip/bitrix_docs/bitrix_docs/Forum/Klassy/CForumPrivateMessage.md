[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPrivateMessage](/api_help/forum/developer/cforumprivatemessage/index.php)

Класс CForumPrivateMessage (доступен с 4.0.3)

Класс CForumPrivateMessage
==========================

**CForumPrivateMessage** - класс для работы с приватными сообщениями.

#### Методы класса

| Метод | Описание | C версии |
| --- | --- | --- |
| [Delete](/api_help/forum/developer/cforumprivatemessage/delete.php) | Удаление сообщения. | 4.0.3 |
| [GetList](/api_help/forum/developer/cforumprivatemessage/getlist.php) | Получение списка сообщений с возможностью фильтрации и сортировки. | 4.0.3 |
| [GetByID](/api_help/forum/developer/cforumprivatemessage/getbyid.php) | Получение параметров сообщения по его коду. | 4.0.3 |
| [Send](/api_help/forum/developer/cforumprivatemessage/send.php) | Добавление (отправка) нового сообщения. | 4.0.3 |
| [Update](/api_help/forum/developer/cforumprivatemessage/update.php) | Изменение параметров сообщения. | 4.0.3 |
| [GetNewPM](/api_help/forum/developer/cforumprivatemessage/getnewpm.php) | Получение количества непрочитанных персональных сообщений. | 4.0.3 |

Новинки документации в соцсетях:
[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPoints](/api_help/forum/developer/cforumpoints/index.php)

Delete (доступен с 3.3.7)

Delete
======

```
bool
CForumPoints::Delete(
	int ID
);Копировать
```

Удаляет звание (рейтинг) с кодом ID из системы званий форума. Метод нестатический.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| ID | Код звания для удаления. |

#### Возвращаемые значения

Возвращает True.

####

Новинки документации в соцсетях:
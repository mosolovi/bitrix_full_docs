[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPoints](/api_help/forum/developer/cforumpoints/index.php)

Add (доступен с 3.3.7)

Add
===

```
int
CForumPoints::Add(
	array arFields
);Копировать
```

Функция добавляет новое звание (рейтинг) в систему званий форума. Метод нестатический.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| arFields | Массив атрибутов звания. |

#### Возвращаемые значения

Код добавленного звания или false в случае ошибки.

Новинки документации в соцсетях:
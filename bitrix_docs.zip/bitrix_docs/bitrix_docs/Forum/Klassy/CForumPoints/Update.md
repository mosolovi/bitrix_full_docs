[Форум](/api_help/forum/index.php)

[Классы](/api_help/forum/developer/index.php)

[CForumPoints](/api_help/forum/developer/cforumpoints/index.php)

Update (доступен с 3.3.7)

Update
======

```
int
CForumPoints::Update(
	int ID, 
	array arFields
);Копировать
```

Изменяет параметры звания с кодом ID на значения, указанные в массиве arFields. Метод нестатический.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| ID | Код звания. |
| arFields | Массив новых значений параметров звания. |

#### Возвращаемые значения

Функция возвращает код изменяемого звания или false в случае ошибки.

Новинки документации в соцсетях:
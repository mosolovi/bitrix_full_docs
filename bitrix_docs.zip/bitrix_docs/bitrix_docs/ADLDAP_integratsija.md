AD/LDAP интеграция

AD/LDAP интеграция
==================

Значение полей форм модуля в административной части смотрите в [пользовательской документации](http://dev.1c-bitrix.ru/user_help/settings/ldap/index.php).

О работе с модулем смотрите в [учебном курсе](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=35&CHAPTER_ID=04536&LESSON_PATH=3906.4503.4536).

Новинки документации в соцсетях:
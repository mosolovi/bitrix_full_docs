[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Языковые файлы](/api_help/main/functions/localization/index.php)

Обзор функций

Обзор функций
=============

Функции для работы с языковыми файлами:

| Метод | Описание | С версии |
| --- | --- | --- |
| [GetMessage](/api_help/main/functions/localization/getmessage.php) | Возвращает по коду соответствующее сообщение на текущем языке. | 3.0.3 |
| [IncludeModuleLangFile](/api_help/main/functions/localization/includemodulelangfile.php) | Подключает языковой файл для скрипта модуля. | 3.0.3 |
| [IncludeTemplateLangFile](/api_help/main/functions/localization/includetemplatelangfile.php) | Подключает языковой файл для компонента. | 3.3.21 |

#### Смотрите также

* [Языки](/api_help/main/general/lang/index.php)

Новинки документации в соцсетях:
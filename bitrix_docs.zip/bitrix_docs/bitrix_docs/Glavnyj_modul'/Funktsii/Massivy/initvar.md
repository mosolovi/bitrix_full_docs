[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Массивы](/api_help/main/functions/array/index.php)

initvar (с версии 3.0.3)

initvar
=======

```
function 
initvar(
	varname,
	value=""
);Копировать
```

Инициализирует переменную с именем в $varname значением $value. Если переменная уже определена, ее значение не меняется.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| varname | Имя переменной |
| *value* | Значение переменной |

Новинки документации в соцсетях:
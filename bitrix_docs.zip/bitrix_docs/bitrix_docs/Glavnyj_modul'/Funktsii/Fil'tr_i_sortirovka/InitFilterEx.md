[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Фильтр и сортировка](/api_help/main/functions/filter/index.php)

InitFilterEx (с версии 3.0.3)

InitFilterEx
============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
InitFilterEx(
	array vars,
	string id, 
	string action = "set", 
	bool session = true
);Копировать
```

Инициализирует, либо запоминает переменные фильтра в сессии.

**Примечание**. Функция работает с переменными из глобальной области видимости, это необходимо учитывать при [создании основных файлов компонентов](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=2818).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *vars* | Массив имен переменных фильтра. |
| *id* | Идентификатор фильтра. Строка идентифицирующая данный фильтр в сессионном массиве: $\_SESSION["SESS\_ADMIN"][*id*] |
| *action* | Что необходимо сделать: запомнить значения или получить значения фильтра. Если значение равно "set", то значения переменных имена которых были переданы в параметре *vars* будут запомнены в сессионном массиве $\_SESSION["SESS\_ADMIN"][*id*]. В противном случае эти переменный будут инициализированы значениями хранящимися в сессионном массиве $\_SESSION["SESS\_ADMIN"][*id*]. Параметр необязательный. По умолчанию - "set". |
| *session* | Использовать ли сессию. Если значение данного параметра равно "true", то значения фильтра будут запоминаться в сессионном массиве $\_SESSION["SESS\_ADMIN"][*id*]. |

### Смотрите также

* [DelFilterEx](/api_help/main/functions/filter/delfilterex.php)

### Примеры использования

```
<?
$FilterArr = Array(
	"find_id",
	"find_id_exact_match",
);
// если нажата кнопка "Установить фильтр" то
if (strlen($set_filter)>0) 
{
	// запоминаем значения фильтра в сессии
	InitFilterEx($FilterArr,"ADV_BANNER_LIST","set"); 
}
else 
{
	// инициализируем значения фильтра из сессии
	InitFilterEx($FilterArr,"ADV_BANNER_LIST","get");
}
// если была нажата кнопка "Сбросить фильтр"
if (strlen($del_filter)>0) DelFilterEx($FilterArr,"ADV_BANNER_LIST");
$arFilter = Array(
	"ID"                    => $find_id,
	"ID_EXACT_MATCH"        => $find_id_exact_match,
);
$rsBanners = CAdvBanner::GetList($by, $order, $arFilter, $is_filtered);
?>Копировать
```

Новинки документации в соцсетях:
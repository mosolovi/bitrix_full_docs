[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Языковые файлы](/api_help/main/functions/localization/index.php)

IncludeTemplateLangFile (с версии 3.3.21)

IncludeTemplateLangFile
=======================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
IncludeTemplateLangFile(
	string abs_path,
	string lang = false
);Копировать
```

Предназначена для подключения языковых файлов для скриптов лежащих в каталоге текущего шаблона сайта. Как правило используется в [компонентах](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&CHAPTER_ID=04565), либо в прологе и/или эпилоге сайта.

Алгоритм поиска языкового файла:

1. Сначала языковой файл будет искаться в каталоге
     
     
   `/bitrix/templates/ID текущего шаблона сайта/lang/ID языка/относительный путь к скрипту`
2. Если файл не найден, он будет искаться в каталоге
     
     
   `/bitrix/templates/.default/lang/ID языка/относительный путь к скрипту`
3. Затем если файл не найден, он будет искаться дистрибутиве модуля, т.е. в каталоге
     
     
   `/bitrix/modules/ID модуля/install/templates/lang/ID языка/относительный путь к скрипту`

В общем случае, под "*относительный путь к скрипту*", понимается путь к файлу относительно каталога `/bitrix/templates/ID текущего шаблона сайта/`.

В частном случае, при подключении компонент, под "*относительный путь к скрипту*", понимается путь для подключения компонента передаваемый в функцию [CMain::IncludeFile](/api_help/main/reference/cmain/includefile.php) в качестве первого параметра.

В новом ядре D7 имеет аналог: [Bitrix\Main\Localization\Loc::loadMessages](http://dev.1c-bitrix.ru/api_d7/bitrix/main/localization/loc/loadmessages.php).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *abs\_path* | Абсолютный путь к файлу, для которого необходимо подключить языковые сообщения. |
| *lang* | Идентификатор языка.  Необязательный параметр, по умолчанию равен "false" (текущий язык). |

### Смотрите также

* [Что такое "языковые файлы"](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=3486)
* [Языковые файлы модулей](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=3491#lang)
* [IncludeModuleLangFile](/api_help/main/functions/localization/includemodulelangfile.php)

### Примеры использования

```
<?
// Подключим языковой файл для текущего компонента
// Предполагаем, что языковой файл расположен стандартным образом
IncludeTemplateLangFile(__FILE__);
?>Копировать
```

Новинки документации в соцсетях:
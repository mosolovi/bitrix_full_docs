[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Языковые файлы](/api_help/main/functions/localization/index.php)

IncludeModuleLangFile

IncludeModuleLangFile
=====================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
IncludeModuleLangFile(
	string abs_path,
	string lang = false,
	bool ReturnArray=false
);Копировать
```

Подключает языковой файл для скрипта, полный путь к которому передается в параметре *path*. Как правило данная функция используется для подключения языковых файлов модулей.

Подключаемый языковой файл должен иметь то же имя, что и подключающий файл, и быть расположен на диске в каталоге:`/bitrix/modules/ID модуля/lang/ID языка/путь к файлу относительно корня модуля`

В новом ядре D7 имеет аналог: [Bitrix\Main\Localization\Loc::loadMessages](http://dev.1c-bitrix.ru/api_d7/bitrix/main/localization/loc/loadmessages.php).

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *abs\_path* | Абсолютный путь к файлу, для которого необходимо подключить языковые сообщения. |  |
| *lang* | Идентификатор языка.  Необязательный параметр, по умолчанию равен "false" (текущий язык). | 3.3.21 |
| *ReturnArray* | Массив возвращаемых значений.  Необязательный параметр, по умолчанию равен "false". | 6.5.1 |

### Смотрите также

* [Что такое "языковые файлы"](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=3486)
* [Языковые файлы модулей](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=3491#lang)
* [IncludeTemplateLangFile](/api_help/main/functions/localization/includetemplatelangfile.php)

### Примеры использования

```
<?
// Подключим языковой файл для текущего скрипта
IncludeModuleLangFile(__FILE__);
?>Копировать
```

Новинки документации в соцсетях:
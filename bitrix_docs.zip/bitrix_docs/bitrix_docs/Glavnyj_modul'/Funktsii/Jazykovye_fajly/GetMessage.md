[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Языковые файлы](/api_help/main/functions/localization/index.php)

GetMessage (с версии 3.0.3)

GetMessage
==========

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
string
GetMessage(
	string name,
	array Replace=false
);Копировать
```

Возвращает по коду соответствующее сообщение на текущем языке. Массивы соответствий кодов и сообщений задаются в языковых файлах. Перед использованием этой функции необходимо подключить соответствующий языковой файл.

В ядре D7 аналог этой функции: [Bitrix\Main\Localization\Loc::getMessage](http://dev.1c-bitrix.ru/api_d7/bitrix/main/localization/loc/getmessage.php).

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *name* | Код сообщения. Код должен быть уникальным в рамках всего продукта. |  |
| *Replace* | Массив пар "шаблон" => "замена". Позволяет организовать замену по шаблону. | 5.0.4 |

### Смотрите также

* [IncludeModuleLangFile](/api_help/main/functions/localization/includemodulelangfile.php)
* [IncludeTemplateLangFile](/api_help/main/functions/localization/includetemplatelangfile.php)

### Примеры использования

```
<?
IncludeTemplateLangFile(__FILE__);
echo GetMessage("SOME_MESSAGE_CODE");
?>Копировать
```

**Замена языковой фразы по шаблону**

Языковой файл:

```
$MESS["ERROR_MODULE_NOT_FOUND"] = "Ошибка: модуль #MODULE# не найден"Копировать
```

Файл компонента или модуля:

```
// ...
if (!CModule::IncludeModule("blog"))
{
	ShowError(GetMessage("ERROR_MODULE_NOT_FOUND", Array ("#MODULE#" => "blog")));Копировать
```

Новинки документации в соцсетях:
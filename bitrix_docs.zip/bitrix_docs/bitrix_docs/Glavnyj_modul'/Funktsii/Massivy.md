[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Массивы](/api_help/main/functions/array/index.php)

Обзор функций

Обзор функций
=============

Функции для работы с массивами:

| Метод | Описание | С версии |
| --- | --- | --- |
| [TrimArr](/api_help/main/functions/array/trimarr.php) | Удаляет из массива все элементы с пустыми значениями. | 3.0.3 |
| [is\_set](/api_help/main/functions/array/is_set.php) | Проверяет переменную (или ключ массива) на существование. | 3.0.3 |
| [initvar](/api_help/main/functions/array/initvar.php) | Инициализирует переменную. | 3.0.3 |

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

Обзор функций

Обзор функций
=============

| Метод | Описание | С версии |
| --- | --- | --- |
| [check\_email](/api_help/main/functions/other/check_email.php) | Проверяет E-Mail адрес на синтаксическую корректность. | 3.0.3 |
| [FindUserID](/api_help/main/functions/other/finduserid.php) | Выводит ряд HTML элементов позволяющих задать ID пользователя и рядом с этим полем ввода получить данные пользователя. Также выводиться кнопка ведущая на страницу поиска пользователя. | 3.3.10 |
| [LocalRedirect](/api_help/main/functions/other/localredirect.php) | Выполняет перенаправление браузера на указанную страницу. | 3.0.3 |
| [QueryGetData](/api_help/main/functions/other/querygetdata.php) | Запрашивает web-адрес по протоколу HTTP. | 3.1.6 |
| [GetWhoisLink](/api_help/main/functions/other/getwhoislink.php) | Возвращает ссылку на один из сайтов службы Whois для получения данных по заданному IP адресу. | 3.3.0 |
| [DeleteParam](/api_help/main/functions/other/deleteparam.php) | На основе стандартного массива $HTTP\_GET\_VARS формирует строку параметров, удаляя из нее указанные параметры. | 3.0.3 |
| [InitURLParam](/api_help/main/functions/other/initurlparam.php) | Инициализирует необходимые переменные из параметров заданного URL'а. | 4.0.6 |
| [IsIE](/api_help/main/functions/other/isie.php) | Проверяет, является ли текущий браузер посетителя браузером "MS Internet Explorer". | 3.0.10 |
| [Rel2Abs](/api_help/main/functions/other/rel2abs.php) | Формирует путь относительно заданного каталога. | 3.0.3 |
| [BXClearCache](/api_help/main/functions/other/bxclearcache.php) | Удаляет файлы кеша по указанному пути. | 3.3.7 |
| [GetCountryByID](/api_help/main/functions/other/getcountrybyid.php) | Возвращает название страны на заданном языке. | 3.0.7 |
| [GetCountryArray](/api_help/main/functions/other/getcountryarray.php) | Возвращает отсортированный массив стран с названиями на заданном языке. | 3.0.6 |
| [ShowError](/api_help/main/functions/other/showerror.php) | Вывод сообщений об ошибках. | 3.0.3 |
| [ShowNote](/api_help/main/functions/other/shownote.php) | Вывод нотификаций. | 3.0.3 |
| [ShowMessage](/api_help/main/functions/other/showmessage.php) | Вывод сообщений об ошибках и прочих сообщений. | 3.0.3 |
| [bitrix\_sessid\_get](/api_help/main/functions/other/bitrix_sessid_get.php) | Передача идентификатора сессии. | 4.0.8 |
| [bitrix\_sessid\_post](/api_help/main/functions/other/bitrix_sessid_post.php) | Передача идентификатора сессии | 4.0.8 |
| [bxmail](/api_help/main/functions/other/bxmail.php) | Проверяет существование функции custom\_mail и вызывает её. | 7.1.3 |
| [check\_bitrix\_sessid](/api_help/main/functions/other/check_bitrix_sessid().php) | проверяет условие условие $\_REQUEST[$varname] == bitrix\_sessid(). | 4.0.8 |
| [bitrix\_sessid](/api_help/main/functions/other/bitrix_sessid.php) | Возвращает идентификатор сессии, предварительно обработанный функцией md5. | 4.0.8 |
| [roundEx](/api_help/main/functions/other/roundex.php) | Округляет сверху значение. | 3.0.3 |

Новинки документации в соцсетях:
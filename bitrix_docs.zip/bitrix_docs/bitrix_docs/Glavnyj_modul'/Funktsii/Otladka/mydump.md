[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Отладка](/api_help/main/functions/debug/index.php)

mydump (с версии 3.0.3)

mydump
======

Включить вкладки

Описание и параметры

Примеры

### Описание и параметры

```
string
mydump(
	mixed var,
	int max_depth = -1,
	int depth = 0
);Копировать
```

Возвращает визуальное представление значения (дамп) переменной или объекта класса.

Аналог функции в новом ядре D7^ *Bitrix\Main\Diag\Debug::dump*.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *var* | Переменная для дампа. |
| *max\_depth* | Максимальное количество рекурсивных вызовов данной функции в момент создания дампов сложных массивов или объектов класса с большой вложенностью. Необязательный параметр, по умолчанию - -1 (не ограничено). |
| *depth* | Счетчик рекурсивных вызовов данной функции в момент создания дампов сложных массивов или объектов класса с большой вложенностью.  Необязательный параметр, по умолчанию - 0 (начальное значение). |

### Примеры

#### Пример вызова функции

```
<?
// создадим дамп стандартного объекта класса CUser
echo "<pre>";
echo mydump($USER);
echo "</pre>";
?>Копировать
```

#### Пример результата

```
<?
object(cuser) =>
	method(0) => Array[0]
	method(1) => Array[1]
	method(2) => Array[2]
	method(3) => Array[3]
	method(4) => Array[4]
	method(5) => Array[5]
	method(6) => Array[6]
	method(7) => Array[7]
	method(8) => Array[8]
	method(9) => Array[9]
	method(10) => Array[10]
	method(11) => Array[11]
	method(12) => Array[12]
	method(13) => Array[13]
	method(14) => Array[14]
	method(15) => Array[15]
	method(16) => Array[16]
	method(17) => Array[17]
	method(18) => Array[18]
	method(19) => Array[19]
	method(20) => Array[20]
	method(21) => Array[21]
	method(22) => Array[22]
	method(23) => Array[23]
	method(24) => Array[24]
	method(25) => Array[25]
	method(26) => Array[26]
	method(27) => Array[27]
	method(28) => Array[28]
	method(29) => Array[29]
	method(30) => Array[30]
	method(31) => Array[31]
	method(32) => Array[32]
	method(33) => Array[33]
	method(34) => Array[34]
	method(35) => Array[35]
	method(36) => Array[36]
	method(37) => Array[37]
	method(38) => Array[38]
	method(39) => Array[39]
	method(40) => Array[40]
	method(41) => Array[41]
	method(42) => Array[42]
	method(43) => Array[43]
	method(44) => Array[44]
	method(45) => Array[45]
	method(46) => Array[46]
	method(47) => Array[47]
	method(48) => Array[48]
	method(49) => Array[49]
	method(50) => Array[50]
	method(51) => Array[51]
	method(52) => Array[52]
	method(53) => Array[53]
	method(54) => Array[54]
	method(55) => Array[55]
	default => result =>
		NULL()  default => arResult =>
		NULL()  default => bNavStart =>
		boolean(true)  default => bShowAll =>
		boolean(true)  default => NavNum =>
		NULL()  default => NavPageCount =>
		NULL()  default => NavPageNomer =>
		NULL()  default => NavPageSize =>
		NULL()  default => NavShowAll =>
		NULL()  default => NavRecordCount =>
		NULL()  default => bFirstPrintNav =>
		boolean(true)  default => PAGEN =>
		NULL()  default => SIZEN =>
		NULL()  default => bFromArray =>
		boolean(true)  default => bFromLimited =>
		boolean(true)  default => sSessInitAdd =>
		string(0) =>
		""
	default => nPageWindow =>
		integer(11)  default => nSelectedCount =>
		boolean(true)  default => SESS_AUTH =>
		NULL()  default => LAST_ERROR =>
		string(0) =>
		""
	result =>
		NULL()  arResult =>
		NULL()  bNavStart =>
		boolean(true)  bShowAll =>
		boolean(true)  NavNum =>
		NULL()  NavPageCount =>
		NULL()  NavPageNomer =>
		NULL()  NavPageSize =>
		NULL()  NavShowAll =>
		NULL()  NavRecordCount =>
		NULL()  bFirstPrintNav =>
		boolean(true)  PAGEN =>
		NULL()  SIZEN =>
		NULL()  bFromArray =>
		boolean(true)  bFromLimited =>
		boolean(true)  sSessInitAdd =>
		string(0) =>
		""
	nPageWindow =>
		integer(11)  nSelectedCount =>
		boolean(true)  SESS_AUTH =>
		array(10) => 
		[AUTHORIZED] =>
			string(1) =>
			"Y"
		[USER_ID] =>
			string(1) =>
			"2"
		[LOGIN] =>
			string(5) =>
			"nessy"
		[EMAIL] =>
			string(15) =>
			"mail@server.com"
		[PASSWORD_HASH] =>
			string(32) =>
			"fc0b9bd428702e477fb6a6fbc3da211c"
		[NAME] =>
			string(14) =>
			"Vitaly Kaplich"
		[FIRST_NAME] =>
			string(6) =>
			"Vitaliy"
		[LAST_NAME] =>
			string(7) =>
			"Kaplich"
		[GROUPS] =>
			array(3) => 
			[0] =>
				integer(2)             [1] =>
				integer(1)             [2] =>
				integer(3)         [ADMIN] =>
			boolean(true)  LAST_ERROR =>
		string(0) =>
		""
?>Копировать
```

Новинки документации в соцсетях:
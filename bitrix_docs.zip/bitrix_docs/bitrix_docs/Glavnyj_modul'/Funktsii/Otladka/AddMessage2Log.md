[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Отладка](/api_help/main/functions/debug/index.php)

AddMessage2Log (с версии 3.3.0)

AddMessage2Log
==============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
AddMessage2Log(
	string text,
	string module_id = "",
	traceDepth = 6,
	bool ShowArgs = false
);Копировать
```

Функция добавляет новую запись в log-файл. Путь до файла (или имя файла) рекомендуется делать уникальным в рамках каждого проекта.

Для работы функции необходимо, чтобы до ее вызова была определена константа **LOG\_FILENAME**, содержащая абсолютный путь к log-файлу. Если эта константа не определена, то функция не выполняет никаких действий. Константа **LOG\_FILENAME** при необходимости определяется в начале текущей страницы или в одном из файлов:

* **/bitrix/php\_interface/dbconn.php**
* **/bitrix/php\_interface/***ID сайта***/init.php**

Данная функция вызывается в случае ошибки в следующих функциях:

* [CDataBase::Query](/api_help/main/reference/cdatabase/query.php)
* [CDataBase::QueryBind](/api_help/main/reference/cdatabase/querybind.php)
* [CDataBase::QueryBindSelect](/api_help/main/reference/cdatabase/querybindselect.php)

Log-файл накапливает все добавленные в него сообщения. Для очистки log-файла его можно просто удалить с диска.

**Примечание**. Существует возможность записывать в отдельный отладочный файл все запросы к базе данных и время их выполнения, для этого необходимо инициализировать [переменную $DBDebugToFile](/api_help/main/general/magic_vars.php#dbdebugtofile), значением "true" в файле **/bitrix/php\_interface/dbconn.php**.

Аналог функции в новом ядре: *Bitrix\Main\Diag\Debug::dumpToFile* и *Bitrix\Main\Diag\Debug::writeToFile*.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *text* | Текст сообщения. |  |
| *module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php), который сохраняет сообщение. Необязательный параметр, по умолчанию - "". |  |
| *traceDepth* | Необязательный параметр, по умолчанию - "6". | 11.0.14 |
| *ShowArgs* | Необязательный параметр, по умолчанию - "false". | 11.0.14 |

### Смотрите также

[Специальные переменные включающие отладку](/api_help/main/general/magic_vars.php#dbdebug)

### Примеры использования

```
<?
// файл /bitrix/php_interface/dbconn.php
// определим константу LOG_FILENAME, в которой зададим путь к лог-файлу
define("LOG_FILENAME", $_SERVER["DOCUMENT_ROOT"]."/log.txt");
?>Копировать
```

```
<?
// Сохраним в лог сообщение
AddMessage2Log("Произвольный текст сообщения", "my_module_id");
?>Копировать
```

```
<?
// выполним преднамеренно некорректный SQL-запрос
$DB->Query("SELECT");
// работа скрипта будет прекращена и в лог-файл будет добавлено сообщение об ошибке
?>Копировать
```

```
define("LOG_FILENAME", $_SERVER["DOCUMENT_ROOT"] . "/_logs/bx/" . date("Y_m_d") . "_PROJECT_UNIQUE_POSTFIX.log");Копировать
```

Новинки документации в соцсетях:
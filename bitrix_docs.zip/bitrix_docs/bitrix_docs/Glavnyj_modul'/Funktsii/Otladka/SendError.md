[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Отладка](/api_help/main/functions/debug/index.php)

SendError (с версии 3.0.3)

SendError
=========

Включить вкладки

Описание и параметры

Примеры использования

### Описание и параметры

```
SendError(
	string text,
	string module_id = ""
);Копировать
```

Отсылает по E-Mail сообщение об ошибке.

Для работы функции необходимо, чтобы до ее вызова была определена константа **ERROR\_EMAIL**, содержащая E-Mail адрес на который будут отправляться сообщения об ошибках. Если эта константа не определена, то функция не выполняет никаких действий. Константа **ERROR\_EMAIL** при необходимости определяется в начале текущей страницы или в одном из файлов:

* **/bitrix/php\_interface/dbconn.php**
* **/bitrix/php\_interface/***ID сайта***/init.php**

В константе **ERROR\_EMAIL** может быть определено несколько адресов, на которые отсылать сообщения:

```
define("ERROR_EMAIL", "admin1@site.ru, admin2@site.ru");Копировать
```

Помимо текста ошибки, в письмо будут включены:

* **HTTP\_GET\_VARS** - массив переменных пришедших на страницу в HTTP запросе типа GET
* **HTTP\_POST\_VARS** - массив переменных пришедших на страницу в HTTP запросе типа POST
* **HTTP\_COOKIE\_VARS** - массив переменных хранящихся у посетителя на локальной машине (cookie)
* **HTTP\_SERVER\_VARS** - массив стандартных серверных переменных

Данная функция вызывается в случае ошибки в следующих функциях:

* [CDataBase::Connect](/api_help/main/reference/cdatabase/connect.php)
* [CDataBase::Query](/api_help/main/reference/cdatabase/query.php)
* [CDataBase::QueryBind](/api_help/main/reference/cdatabase/querybind.php)
* [CDataBase::QueryBindSelect](/api_help/main/reference/cdatabase/querybindselect.php)
* [CDBResult::Fetch](/api_help/main/reference/cdbresult/fetch.php) (только для Oracle версии)

Для корректной отправки сообщений об ошибке необходимо также определять константы:  
**ERROR\_EMAIL\_FROM**,   
**ERROR\_EMAIL\_REPLY\_TO**.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *text* | Текст сообщения. |
| *module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php), который сохраняет сообщение. Необязательный параметр, по умолчанию - "". |

### Примеры использования

```
<?
// файл /bitrix/php_interface/dbconn.php
// определим константу ERROR_EMAIL, в которой зададим E-Mail администратора
define("ERROR_EMAIL", "admin@site.ru");
?>Копировать
```

```
<?
SendError("Произвольное текстовое сообщение");
?>Копировать
```

Новинки документации в соцсетях:
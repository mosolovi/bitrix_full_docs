[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

Обзор функций

Обзор функций
=============

Функции для работы с файловой системой сайта:

| Метод | Описание | С версии |
| --- | --- | --- |
| [CheckDirPath](/api_help/main/functions/file/checkdirpath.php) | Проверяет физическое существование указанного пути. При необходимости - создает все каталоги входящие в данный путь. | 3.0.3 |
| [CopyDirFiles](/api_help/main/functions/file/copydirfiles.php) | Копирует файлы и каталоги. | 3.0.1 |
| [DeleteDirFiles](/api_help/main/functions/file/deletedirfiles.php) | Удаление из каталога всех файлов, содержащихся в другом каталоге. | 3.0.1 |
| [DeleteDirFilesEx](/api_help/main/functions/file/deletedirfilesex.php) | Рекурсивное удаление каталога или файла. | 3.0.1 |
| [RewriteFile](/api_help/main/functions/file/rewritefile.php) | Перезапись файла. | 3.0.3 |
| [GetDirPath](/api_help/main/functions/file/getdirpath.php) | Получение каталога по полному пути. | 3.0.3 |
| [GetPagePath](/api_help/main/functions/file/getpagepath.php) | Получение пути к файлу по заданному URL'у. | 3.0.3 |
| [GetDirIndex](/api_help/main/functions/file/getdirindex.php) | Определение индексного файла каталога. | 4.0.6 |
| [GetFileExtension](/api_help/main/functions/file/getfileextension.php) | Возвращает расширение файла. | 3.0.14 |
| [GetFileType](/api_help/main/functions/file/getfiletype.php) | Возвращает тип файла. | 3.0.14 |

#### Смотрите также

* [Класс CFile](/api_help/main/reference/cfile/index.php)
* [Права для новых файлов и каталогов](/api_help/main/general/constants.php)

Новинки документации в соцсетях:
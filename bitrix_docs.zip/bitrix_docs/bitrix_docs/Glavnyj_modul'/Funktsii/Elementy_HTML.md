[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Элементы HTML](/api_help/main/functions/html/index.php)

Обзор функций

Обзор функций
=============

Функции для работы с элементами HTML:

| Метод | Описание | С версии |
| --- | --- | --- |
| [InputType](/api_help/main/functions/html/inputtype.php) | Возвращает HTML код тегов <input type="checkbox"> (переключатель с множественным варинтом выбора ответа), либо <input type="radio"> (переключатель с единственным вариантом выбора ответа). | 3.0.3 |
| [SelectBox](/api_help/main/functions/html/selectbox.php) | Возвращает HTML код тега <select> (выпадающий список с единственным вариантом выбора ответа) на основании данных из объекта класса [CDBResult](/api_help/main/reference/cdbresult/index.php). | 3.0.3 |
| [SelectBoxM](/api_help/main/functions/html/selectboxm.php) | Возвращает HTML код тега <select multiple> (выпадающий список с множественными варинтами выбора ответа) на основании данных из объекта класса [CDBResult](/api_help/main/reference/cdbresult/index.php). | 4.0.6 |
| [SelectBoxFromArray](/api_help/main/functions/html/selectboxfromarray.php) | Возвращает HTML код тега <select> (выпадающий список с единственным вариантом выбора ответа) на основании данных из массива. | 3.0.3 |
| [SelectBoxMFromArray](/api_help/main/functions/html/selectboxmfromarray.php) | Возвращает HTML код тега <select multiple> (выпадающий список с множественными варинтами выбора ответа) на основании данных из массива. | 4.0.6 |
| [ShowJSHint](/api_help/main/functions/html/showjshint.php) | Выводит иконку-вопросик, при наведении на которую всплывает текст $text. | 7.0.14 |
| [print\_url](/api_help/main/functions/html/print_url.php) | Возвращает html-код для вставки ссылки. | 3.0.3 |

Новинки документации в соцсетях:
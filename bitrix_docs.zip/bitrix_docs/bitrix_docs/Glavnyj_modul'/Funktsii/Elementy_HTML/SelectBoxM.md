[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Элементы HTML](/api_help/main/functions/html/index.php)

SelectBoxM (с версии 4.0.6)

SelectBoxM
==========

Включить вкладки

Описание и параметры

Смотрите также

Пример использования

### Описание и параметры

```
string
SelectBoxM(
	string name,
	CDBResult values,
	array selected,
	string top_element = "",
	bool select_top_element = false,
	int size = 5,
	string add_to_tag = "class=\"typeselect\""
);Копировать
```

Возвращает HTML код тега <select multiple> (выпадающий список с множественными вариантами выбора ответа) на основании данных из объекта класса [CDBResult](/api_help/main/reference/cdbresult/index.php).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *name* | Имя тэга:  <select name="*name*" ... > |
| *values* | Элементы списка. Объект типа [CDBResult](/api_help/main/reference/cdbresult/index.php), содержащий набор записей, каждая из которых должна иметь по два: "REFERENCE\_ID" (значение элемента списка) и "REFERENCE" (заголовок элемента списка). |
| *selected* | Выбранные элементы. Массив, элементы которого будут сравниваться с полями "REFERENCE\_ID" набора записей передаваемого в параметре *values*, в случае совпадения элемент будет "выбран" (selected). |
| *top\_element* | Заголовок специального элемента который всегда помещается первым в списке и он может быть всегда выбран (контролируется параметром *select\_top\_element*). Значение этого элемента - "NOT\_REF". Необязательный параметр. По умолчанию - "" (не добавлять подобный элемент). |
| *select\_top\_element* | Если значение "true", то элемент *top\_element* будет всегда выбран (selected).  Необязательный параметр. По умолчанию - "false" (не выбирать). |
| *size* | Поле size тэга select:  <select size="*size*" ... >  В данном параметре передается количество видимых строк в списке множественного выбора. Параметр необязательный. Значение по умолчанию - 5. |
| *add\_to\_tag* | Произвольный HTML который будет добавлен в тэг:  <select *add\_to\_tag* ... >  Необязательный параметр. По умолчанию - "class=\"typeselect\"". |

### Смотрите также

* [SelectBoxMFromArray](/api_help/main/functions/html/selectboxmfromarray.php)

### Пример использования

```
<?
// сформируем выборку из таблицы групп
$strSql = "
	SELECT
		G.ID as REFERENCE_ID,
		G.NAME as REFERENCE
	FROM
		b_group G
	WHERE
		G.ID<>2 -- группа everybody которой все принадлежат по умолчанию
";
$rs = $DB->Query($strSql, false, "FILE: ".__FILE__."<br>LINE: ".__LINE__);
// выведем список групп с множественным выбором
echo SelectBoxM("arrGROUP[]", $rs, $arrGROUP, "< группа everybody >", true, 20, 
"class =\"inputselect\"");
?>Копировать
```

Новинки документации в соцсетях:
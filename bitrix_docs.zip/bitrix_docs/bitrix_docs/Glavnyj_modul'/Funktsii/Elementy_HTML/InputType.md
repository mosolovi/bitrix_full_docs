[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Элементы HTML](/api_help/main/functions/html/index.php)

InputType (с версии 3.0.3)

InputType
=========

Включить вкладки

Описание и параметры

Примеры использования

### Описание и параметры

```
string
InputType(
	string type,
	string name,
	string value,
	mixed Cmp,
	bool print_value = false,
	string Print = "",
	string add_to_tag = "",
	string Id=""
);Копировать
```

Возвращает HTML код тегов <input type="checkbox"> (переключатель с множественным вариантом выбора ответа), либо <input type="radio"> (переключатель с единственным вариантом выбора ответа).

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *type* | Тип тэга:  <input type="*type*" ... >   Возможные значения:  * **checkbox** - переключатель с множественным вариантом выбора ответа * **radio** - переключатель с единственным вариантом выбора ответа |  |
| *name* | Имя тэга:  <input name="*name*" ... > |  |
| *value* | Значение тэга:  <input value="*value*" ... > |  |
| *Cmp* | Значение данного параметра будет сравниваться со значением параметра *value*, в случае совпадения - переключатель будет "отмечен" (checked):  <input checked ... > |  |
| *print\_value* | Если в данном параметре задано значение "true", то справа от тэга будет выведено значение параметра *value*. Необязательный параметр. По умолчанию - "false". |  |
| *Print* | Если параметр *print\_value* не равен "true" и в параметре *title* задано значение, то оно будет выведено справа от тэга. Необязательный параметр. По умолчанию - "". |  |
| *field1* | Произвольный HTML который будет добавлен в тэг:  <input *add\_to\_tag* ... >  Необязательный параметр. По умолчанию - "". |  |
| *Id* | Необязательный параметр. По умолчанию - "". | 11.0.5 |

### Примеры использования

```
<?
// Множественный выбор
echo "Результат выбора:<pre>"; print_r($check); echo "</pre>";
echo "Отметьте нужные варианты:<br>";
?>
<form action="" method="GET">
<?
echo "1:".InputType("checkbox", "check[]", "1", $check)."<br>";
echo "2:".InputType("checkbox", "check[]", "2", $check)."<br>";
echo "3:".InputType("checkbox", "check[]", "3", $check)."<br>";
?>
<br><input type="submit" value="OK">
</form>Копировать
```

```
<?
// Единичный выбор
echo "Результат выбора: ".$radio."<br><br>";
echo "Выберете один из следующих вариантов:<br>";
?>
<form action="" method="GET">
<?
echo "1: ".InputType("radio", "radio", "1", $radio)."<br>";
echo "2: ".InputType("radio", "radio", "2", $radio)."<br>";
echo "3: ".InputType("radio", "radio", "3", $radio)."<br>";
echo "4: ".InputType("radio", "radio", "4", $radio)."<br>";
?>
<br><input type="submit" value="OK">
</form>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Элементы HTML](/api_help/main/functions/html/index.php)

print\_url (с версии 3.0.3)

print\_url
==========

```
result_type
print_url(
	strUrl,
	strText,
	sParams=""
);Копировать
```

Возвращает html-код для вставки ссылки на $strUrl с якорем $strText:

```
<a href="$strUrl" $sParams>$strText</a>Копировать
```

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| strUrl | адрес |
| strText | текст якоря |
| *sParams* | Параметры ссылки |

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Элементы HTML](/api_help/main/functions/html/index.php)

ShowJSHint (с версии 7.0.14)

ShowJSHint
==========

```
result_type
ShowJSHint(
	string text,
	array Params = false
);Копировать
```

Подсказка. Выводит иконку-вопросик, при наведении на которую всплывает текст $text.

**Примечание**. По умолчанию метод работает только в административной части. Метод может работать и в публичной части при подключении файла `\bitrix\modules\main\interface\admin_lib.php`.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| text | Выводимый текст |
| *Params* | Параметры вывода. Если передать вторым параметром `array('return' => true)`, то вместо вывода на экран, будет возвращен html-код подсказки. |

Новинки документации в соцсетях:
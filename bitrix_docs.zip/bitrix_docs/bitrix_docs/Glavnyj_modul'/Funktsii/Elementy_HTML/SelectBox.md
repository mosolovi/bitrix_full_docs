[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Элементы HTML](/api_help/main/functions/html/index.php)

SelectBox (с версии 3.0.3)

SelectBox
=========

Включить вкладки

Описание и параметры

Смотрите также

Пример использования

### Описание и параметры

```
string
SelectBox(
	string name,
	CDBResult values,
	string default = "",
	string selected = "",
	string add_to_tag = "class=\"typeselect\""
);Копировать
```

Возвращает HTML код тега <select> (выпадающий список с единственным вариантом выбора ответа) на основании данных из объекта класса [CDBResult](/api_help/main/reference/cdbresult/index.php).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *name* | Имя тэга:  <select name="*name*" ... > |
| *values* | Элементы списка. Объект типа [CDBResult](/api_help/main/reference/cdbresult/index.php), содержащий набор записей, каждая из которых должна иметь по два: "REFERENCE\_ID" (значение элемента списка) и "REFERENCE" (заголовок элемента списка). |
| *default* | Заголовок элемента списка выбираемого по умолчанию. Значение этого элемента - "NOT\_REF".  Необязательный параметр. По умолчанию - "" (не добавлять подобный элемент). |
| *selected* | Выбранный элемент. Значение данного параметра будет сравниваться с полями "REFERENCE\_ID" набора записей передаваемого в параметре *values*, в случае совпадения элемент будет "выбран" (selected). Необязательный параметр. По умолчанию - "". |
| *add\_to\_tag* | Произвольный HTML который будет добавлен в тэг:  <select *add\_to\_tag* ... >  Необязательный параметр. По умолчанию - "class=\"typeselect\"". |

### Смотрите также

* [SelectBoxFromArray](/api_help/main/functions/html/selectboxfromarray.php)

### Пример использования

```
<?
// сформируем выборку из таблицы групп
$strSql = "
	SELECT
		G.ID as REFERENCE_ID,
		G.NAME as REFERENCE
	FROM
		b_group G
";
$rs = $DB->Query($strSql, false, "FILE: ".__FILE__."<br>LINE: ".__LINE__);
// выведем выпадающий список групп
echo SelectBox("GROUP", $rs, "< выберите группу >", $GROUP, "class =\"inputselect\"");
?>Копировать
```

Новинки документации в соцсетях:
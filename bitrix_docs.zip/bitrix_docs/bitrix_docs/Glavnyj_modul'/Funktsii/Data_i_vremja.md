[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

Обзор функций

Обзор функций
=============

Функции для работы с датами, временем и календарем:

| Метод | Описание | С версии |
| --- | --- | --- |
| [Calendar](/api_help/main/functions/date/calendar.php) | Возвращает иконку, при нажатии на которую появляется стандартное окно выбора даты. Выбранная в этом окне дата вставляется в указанное поле формы (либо, в случае выбора интервала - в два поля). | 3.0.3 |
| [CalendarDate](/api_help/main/functions/date/calendardate.php) | Возвращает поле ввода и иконку, при нажатии на которую появляется стандартное окно выбора даты. Выбранная в этом окне дата вставляется в поле ввода. | 3.0.3 |
| [CalendarPeriod](/api_help/main/functions/date/calendarperiod.php) | Отображает два поля ввода для дат "с" и "по" с иконками, при нажатии на которые появляется стандартное окно выбора даты, помимо этого рядом с первым полем выводится выпадающий список дней для быстрого выбора даты "с". | 3.0.3 |
| [ParseDateTime](/api_help/main/functions/date/parsedatetime.php) | Разбивает дату и время на части в соответствии с заданным форматом. | 4.0.6 |
| [ConvertDateTime](/api_help/main/functions/date/convertdatetime.php) | Конвертирует дату из формата одного из сайтов в строку произвольного формата. | 4.0.6 |
| [MakeTimeStamp](/api_help/main/functions/date/maketimestamp.php) | Конвертирует время из строки в Unix-формат. | 4.0.6 |
| [ConvertTimeStamp](/api_help/main/functions/date/converttimestamp.php) | Конвертирует время из Unix-формата в строку в формате сайта. | 4.0.6 |
| [AddToTimeStamp](/api_help/main/functions/date/addtotimestamp.php) | Добавляет к дате в Unix-формате заданный интервал времени. | 4.0.6 |
| [getmicrotime](/api_help/main/functions/date/getmicrotime.php) | Возвращает текущее время в Unix-формате. | 3.0.3 |
| [FormatDate](/api_help/main/functions/date/formatdate.php) | Возвращает строку отформатированную в соответствии с заданным форматом. | 9.0.2 |
| [IsAmPmMode](/api_help/main/functions/date/isampmmode.php) | Определяет используется ли 12-и часовой формат времени. | 11.5.4 |
| [FormatDateFromDB](/api_help/main/functions/date/formatdatefromdb.php) | Возвращает дату на языке сайта. | 11.5.4 |

#### Смотрите также

* [Работа с датой и временем](/api_help/main/general/date_time.php)
* Методы класса[Класс CDatabase](/api_help/main/reference/cdatabase/index.php)для работы с датой и временем
* [CheckFilterDates](/api_help/main/functions/filter/checkfilterdates.php)

Новинки документации в соцсетях:
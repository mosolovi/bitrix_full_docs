[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Фильтр и сортировка](/api_help/main/functions/filter/index.php)

Обзор функций

Обзор функций
=============

Функции для построения и работы с фильтрами и сортировками

| Метод | Описание | С версии |
| --- | --- | --- |
| [InitFilterEx](/api_help/main/functions/filter/initfilterex.php) | Инициализация фильтра. | 3.0.3 |
| [DelFilterEx](/api_help/main/functions/filter/delfilterex.php) | Удаление фильтра. | 3.0.3 |
| [GetFilterHiddens](/api_help/main/functions/filter/getfilterhiddens.php) | Позволяет создать набор HTML тэгов типа hidden из набора переменных имена которых передаются в массиве, либо указан префикс имен этих переменных. | 3.0.3 |
| [GetFilterParams](/api_help/main/functions/filter/getfilterparams.php) | Создание строки состоящей из параметров для URL'а из входящего массива переменных, либо переменных имена которых начинаются с указанного префикса. | 3.0.3 |
| [CheckFilterDates](/api_help/main/functions/filter/checkfilterdates.php) | Проверяет две даты введенные в фильтре на корректность. | 3.1.6 |
| [InitSorting](/api_help/main/functions/filter/initsorting.php) | Инициализация сортировки. | 3.0.3 |
| [SortingEx](/api_help/main/functions/filter/sortingex.php) | Генерация "стрелок" сортировки. | 3.0.3 |

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

Обзор функций

Обзор функций
=============

Функции для работы с модулями.

| Метод | Описание | С версии |
| --- | --- | --- |
| [AddEventHandler](/api_help/main/functions/module/addeventhandler.php) | Регистрирует произвольный обработчик событий модуля. | 4.0.6 |
| [CheckVersion](/api_help/main/functions/module/checkversion.php) | Сравнение версий модулей. | 3.0.5 |
| [ExecuteModuleEvent](/api_help/main/functions/module/executemoduleevent.php) | Выполнение обработчика события. | 3.0.1 |
| [GetModuleEvents](/api_help/main/functions/module/getmoduleevents.php) | Запрос списка обработчиков событий. | 3.0.1 |
| [GetModuleID](/api_help/main/functions/module/getmoduleid.php) | Возвращает [идентификатор модуля](/api_help/main/general/identifiers.php), которому принадлежит файл. | 3.0.3 |
| [IsModuleInstalled](/api_help/main/functions/module/ismoduleinstalled.php) | Проверяет установлен ли модуль. | 3.0.1 |
| [RegisterModule](/api_help/main/functions/module/registermodule.php) | Регистрация модуля в системе. | 3.0.1 |
| [RegisterModuleDependences](/api_help/main/functions/module/registermoduledependences.php) | Регистрация нового обработчика события. | 3.0.1 |
| [UnRegisterModule](/api_help/main/functions/module/unregistermodule.php) | Удаляет регистрационную запись модуля. | 3.0.1 |
| [UnRegisterModuleDependences](/api_help/main/functions/module/unregistermoduledependences.php) | Удаляет регистрационную запись обработчика события. | 3.0.1 |
| [RemoveEventHandler](/api_help/main/functions/module/removeeventhandler.php) | Функция отзывает зарегистрированный обработчик. | 6.5.4 |

#### Смотрите также

* [Описание концепции модулей](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&CHAPTER_ID=04609)
* [Класс CModule](/api_help/main/reference/cmodule/index.php)

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Отладка](/api_help/main/functions/debug/index.php)

Обзор функций

Обзор функций
=============

Функции для отладки:

| Метод | Описание | С версии |
| --- | --- | --- |
| [AddMessage2Log](/api_help/main/functions/debug/addmessage2log.php) | Добавляет новую запись в log-файл. | 3.3.0 |
| [SendError](/api_help/main/functions/debug/senderror.php) | Отсылает по E-Mail сообщение об ошибке. | 3.0.3 |
| [mydump](/api_help/main/functions/debug/mydump.php) | Возвращает визуальное представление значения (дамп) переменной или объекта класса. | 3.0.3 |

#### Смотрите также

[Специальные переменные включающие отладку](/api_help/main/general/magic_vars.php#dbdebug)

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

CalendarPeriod (с версии 3.0.3)

CalendarPeriod
==============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
string
CalendarPeriod(
	string field_from_name,
	string field_from_value,
	string field_to_name,
	string field_to_value,
	string form = "skform",
	string select_enabled = "N",
	string select_param = "class=\"typeselect\"",
	string fields_param = "class=\"typeinput\"",
	string fields_size = "10"
);Копировать
```

Отображает два поля ввода для дат "с" и "по" с иконками, при нажатии на которые появляется стандартное окно выбора даты, помимо этого рядом с первым полем выводится выпадающий список дней от 1 до 90, если выбрать какое-либо значение из этого списка, то в первое поле ввода будет установлена текущая дата минус то количество дней которое было выбрано. Работает на JavaScript.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *field\_from\_name* | Имя поля ввода для первой даты ("с"):  <input type="text" name="*field\_from\_name*" ... > |
| *field\_from\_value* | Начальное значение для первой даты ("с"):  <input type="text" value="*field\_from\_value*" ... > |
| *field\_to\_name* | Имя поля ввода для второй даты ("по"):  <input type="text" name="*field\_to\_name*" ... > |
| *field\_to\_value* | Начальное значение для второй даты ("по"):  <input type="text" value="*field\_to\_value*" ... > |
| *form* | Имя формы, в которой находятся поля ввода для вставки дат:  <form name="*form*">  Необязательный параметр, по умолчанию принимает значение - "skform". |
| *select\_enabled* | Если значение "Y", то список дней, состоящий из цифр от 1 до 90, для быстрого выбора даты, будет выведен. Необязательный параметр, по умолчанию принимает значение "N" - список не выводить. |
| *select\_param* | Строка дополнительных аттрибутов для списка дней:  <select name="*field\_from\_name*\_DAYS\_TO\_BACK" *select\_param* ... >  Необязательный параметр, по умолчанию принимает значение - class="typeselect". |
| *fields\_param* | Строка дополнительных аттрибутов для полей ввода дат:  <input type="text" *fields\_param* ... >  Необязательный параметр, по умолчанию принимает значение - class="typeinput". |
| *fields\_size* | Ширина полей ввода:  <input type="text" size="*fields\_size*" ... >  Необязательный параметр, по умолчанию принимает значение - "10". Если значение больше 10, то к дате периода добавляется выбор времени суток. |

### Смотрите также

* [Calendar](/api_help/main/functions/date/calendar.php)
* [CalendarDate](/api_help/main/functions/date/calendardate.php)

### Примеры использования

```
<form action="<?=$APPLICATION->GetCurPage()?>" method="POST" name="form1">
<?echo CalendarPeriod("date_from", "25.10.2003", "date_to", "29.10.2003", "form1", "Y")?>
</form>Копировать
```

Новинки документации в соцсетях:
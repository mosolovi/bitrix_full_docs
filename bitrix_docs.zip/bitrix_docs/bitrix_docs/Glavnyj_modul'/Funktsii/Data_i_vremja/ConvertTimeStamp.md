[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

ConvertTimeStamp (с версии 4.0.6)

ConvertTimeStamp
================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
string
ConvertTimeStamp(
	int timestamp = false,
	string type = "SHORT",
	mixed site = false,
	bool SearchInSitesOnly = false
);Копировать
```

Конвертирует время из Unix-формата в строку в формате сайта.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *timestamp* | Время в Unix-формате. Необязательный параметр, по умолчанию - текущее время. |
| *type* | Тип формата. Допустимы следующие значения:  * **FULL** - полный (дата и время) * **SHORT** - короткий (дата)  Необязательный параметр, по умолчанию равен "SHORT". |
| *site* | Идентификатор сайта, в формате которого необходимо вернуть дату. Необязательный параметр. По умолчанию - текущий сайт. |
| *SearchInSitesOnly* | Искать только на сайте. Необязательный параметр. По умолчанию - "false" текущий сайт. |

### Смотрите также

* [MakeTimeStamp](/api_help/main/functions/date/maketimestamp.php)
* [AddToTimeStamp](/api_help/main/functions/date/addtotimestamp.php)
* [CSite::GetDateFormat](/api_help/main/reference/csite/getdateformat.php)
* [CDataBase::DateFormatToPHP](/api_help/main/reference/cdatabase/dateformattophp.php)

### Примеры использования

```
<?
echo "Сегодня: ".ConvertTimeStamp();
echo "Вчера: ".ConvertTimeStamp(time()-86400);
echo "Позавчера: ".ConvertTimeStamp(time()-(86400*2));
?>Копировать
```

```
<?
echo ConvertTimeStamp(mktime(0, 0, 0, 10, 25, 2003), "SHORT", "ru"); // 25.10.2003
?>Копировать
```

Новинки документации в соцсетях:
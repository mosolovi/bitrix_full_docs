[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

FormatDateFromDB (с версии 11.5.5)

FormatDateFromDB
================

```
string
FormatDateFromDB (
	date,
	format = 'FULL',
	phpFormat = false
);Копировать
```

Возвращает дату на языке сайта.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *date* | Дата заданная в формате сайта |  |
| *format* | Формат, в который следует преобразовать дату.  * **FULL** - полный формат даты; * **SHORT** - короткий формат даты; * Явное указание формата, например, MM/DD/YYYY. ([Форматы](/api_help/main/general/date_time.php))  Необязательный. По умолчанию "FULL". |  |
| *phpFormat* | Необязательный. | 11.5.8 |

#### Примеры использования

```
echo FormatDateFromDB('01/23/2013', 'DD MMMM YYYY'); // вернет 23 Enero 2013, если язык сайта испанский
echo FormatDateFromDB('7 June 2012 12:00pm', 'SHORT'); // вернет 7 Июня 2012, если язык сайта русский и короткий формат языка - DD MMMM YYYY
echo FormatDateFromDB('7 June 2012 12:00pm'); // вернет 7 Июня 2012 12:00pm, если язык русский и полный формат - DD MMMM YYYY G:MIT 
echo FormatDateFromDB('7 June 2012 12:00pm', 'DD.MM'); // вернет 07.06 для любого языка 
Копировать
```

Новинки документации в соцсетях:
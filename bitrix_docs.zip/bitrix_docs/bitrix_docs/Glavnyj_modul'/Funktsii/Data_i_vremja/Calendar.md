[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

Calendar

Calendar
========

Включить вкладки

Описание и параметры

Смотрите также

Пример использования

### Описание и параметры

```
string
Calendar(
	string FieldName,
	string FormName = "skform",
	string FromName = "",
	string ToName = ""
);Копировать
```

Возвращает иконку, при нажатии на которую появляется стандартное окно выбора даты. Выбранная в этом окне дата вставляется в указанное поле формы (либо, в случае выбора интервала - в два поля). Работает на JavaScript.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *FieldName* | Имя поля, в которое будет вставлена выбранная дата. |
| *FormName* | Имя формы, в которой находится поле для вставки даты. Необязательный параметр, по умолчанию принимает значение "skform". |
| *FromName* | Имя поля, в которое будет вставлена первая дата из выбранного интервала (дата "с"). Необязательный параметр, по умолчанию - "". |
| *ToName* | Имя поля, в которое будет вставлена вторая дата из выбранного интервала (дата "по"). Необязательный параметр, по умолчанию - "". |

### Смотрите также

* [CalendarDate](/api_help/main/functions/date/calendardate.php)
* [CalendarPeriod](/api_help/main/functions/date/calendarperiod.php)

### Пример использования

```
<form action="<?=$APPLICATION->GetCurPage()?>" method="POST" name="curform">
<input type="text" class="typeinput" name="DATE" size="12">
<?=Calendar("DATE", "curform")?>
</form>Копировать
```

Новинки документации в соцсетях:
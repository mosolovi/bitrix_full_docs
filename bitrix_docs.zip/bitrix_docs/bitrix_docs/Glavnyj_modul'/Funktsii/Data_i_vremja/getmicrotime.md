[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

getmicrotime (с версии 3.0.3)

getmicrotime
============

```
float 
getmicrotime()Копировать
```

Возвращает текущее время в Unix-формате.

#### Параметры функции

Без параметров.

#### Примеры использования

```
<?
// Алгоритм организации временных засечек
$ptime = getmicrotime();
for ($i=0; $i<10000; $i++);
echo "Цикл выполнялся ".round(getmicrotime()-$ptime, 3)." секунд";
?>Копировать
```

Новинки документации в соцсетях:
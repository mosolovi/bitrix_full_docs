[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

ConvertDateTime (с версии 4.0.6)

ConvertDateTime
===============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
string
ConvertDateTime(
	string datetime,
	string to_format = FORMAT_DATETIME,
	mixed from_site = false,
	bool SearchInSitesOnly = false
);Копировать
```

Конвертирует время из строки в формате сайта в строку произвольного формата.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *datetime* | Время в формате сайта *site\_id*. |
| *to\_format* | Формат времени, в который необходимо сконвертировать. При задании формата допустимо использовать следующие обозначения:  * **YYYY** - год * **MM** - месяц * **DD** - день * **HH** - часы * **MI** - минуты * **SS** - секунды  Необязательный параметр. По умолчанию равен константе  [FORMAT\_DATETIME](/api_help/main/general/constants.php#format_datetime), хранящей текущий формат времени сайта или языка (для административной части). |
| *from\_site* | Идентификатор сайта, в формате которого было задано время *time*. Необязательный параметр. По умолчанию - текущий сайт. |
| *SearchInSitesOnly* | Необязательный параметр. По умолчанию - "false", текущий сайт. |

### Смотрите также

* [CSite::GetDateFormat](/api_help/main/reference/csite/getdateformat.php)
* [CDataBase::FormatDate](/api_help/main/reference/cdatabase/formatdate.php)

### Примеры использования

```
<?
echo ConvertDateTime("25.12.2003", "YYYY-MM-DD", "ru"); // 2003-12-25
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

CalendarDate (с версии 3.0.3)

CalendarDate
============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
string
CalendarDate(
	string FromName,
	string FromVal,
	string FormName = "skform",
	string size = "10",
	string param = "class=\"typeinput\""
);Копировать
```

Возвращает поле ввода и иконку, при нажатии на которую появляется стандартное окно выбора даты. Выбранная в этом окне дата вставляется в поле ввода. Работает на JavaScript.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *FromName* | Имя поля ввода:  <input type="text" name="*field\_name*" ... > |  |
| *FromVal* | Начальное значение для поля ввода:  <input type="text" value="*field\_value*" ... > |  |
| *FormName* | Имя формы, в которой находится поле ввода для вставки даты:  <form name="*form*">  Необязательный параметр, по умолчанию принимает значение - "skform". |  |
| *size* | Ширина поля ввода:  <input type="text" size="*field\_size*" ... >  Необязательный параметр, по умолчанию принимает значение - "10". |  |
| *param* | Строка дополнительных атрибутов поля ввода:  <input type="text" *field\_param* ... >  Необязательный параметр, по умолчанию принимает значение - class="typeinput". | 3.1.6 |

### Смотрите также

* [Calendar](/api_help/main/functions/date/calendar.php)
* [CalendarPeriod](/api_help/main/functions/date/calendarperiod.php)

### Примеры использования

```
<form action="<?=$APPLICATION->GetCurPage()?>" method="POST" name="form1">
<?echo CalendarDate("birthdate", "25.11.1975", "form1", "15", "class=\"my_input\"")?>
</form>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

AddToTimeStamp (с версии 4.0.6)

AddToTimeStamp
==============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
int
AddToTimeStamp(
	array add,
	int tmp = false
);Копировать
```

Добавляет к дате в Unix-формате заданный интервал времени.
Возвращает новую дату также в Unix-формате.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *add* | Массив, описывающий добавляемый интервал времени. Допустимы следующие ключи данного массива:  * **DD** - дни * **MM** - месяцы * **YYYY** - годы * **HH** - часы * **MI** - минуты * **SS** - секунды |
| *tmp* | Время, к которому будет добавляться интервал в Unix-формате. Необязательный параметр, по умолчанию - текущее время. |

### Смотрите также

* [MakeTimeStamp](/api_help/main/functions/date/maketimestamp.php)
* [ConvertTimeStamp](/api_help/main/functions/date/converttimestamp.php)

### Примеры использования

```
$date = "07.04.2005 11:32:00";
echo "Исходная дата: ".$date."<br>";
// получим Unix timestamp из заданной даты
$stmp = MakeTimeStamp($date, "DD.MM.YYYY HH:MI:SS");
// добавим к полученному Unix timestamp 
// 1 день, 1 год, 1 час, 1 минуту, 1 секунду и отнимем 1 месяц
$arrAdd = array(
	"DD"	=> 1,
	"MM"	=> -1,
	"YYYY"	=> 1,
	"HH"	=> 1,
	"MI"	=> 1,
	"SS"	=> 1,
);
$stmp = AddToTimeStamp($arrAdd, $stmp);
// выведем полученную дату
echo "Результат: ".date("d.m.Y H:i:s", $stmp); // 07.03.2006 12:33:01
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

ParseDateTime (с версии 4.0.6)

ParseDateTime
=============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
mixed
ParseDateTime(
	string datetime,
	string format = FORMAT_DATETIME
);Копировать
```

Разбивает дату и время на части в соответствии с заданным форматом. Функция возвращает массив описывающий дату и время в соответствии с заданным форматом, если произошла ошибка - возвращает "false".

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *datetime* | Дата и время заданные в соответствии с форматом указанным в параметре *format*. |
| *format* | Формат даты и времени. Вы можете использовать любые обозначения, но желательно использовать символы формата даты и времени допустимые в системе, а именно:  * **YYYY** - год * **MM** - месяц * **DD** - день * **HH** - часы * **MI** - минуты * **SS** - секунды  Необязательный параметр. По умолчанию равен константе  [FORMAT\_DATETIME](/api_help/main/general/constants.php#format_datetime), хранящей текущий формат времени сайта или языка (для административной части). |

### Смотрите также

* [CSite::GetDateFormat](/api_help/main/reference/csite/getdateformat.php)
* [CDatabase::DateFormatToPHP](/api_help/main/reference/cdatabase/dateformattophp.php)
* [CDatabase::FormatDate](/api_help/main/reference/cdatabase/formatdate.php)

### Примеры использования

```
<?
$datetime = "21.01.2004 23:44:15";
$format = "DD.MM.YYYY HH:MI:SS";
echo "Исходное время: ".$datetime."<br>";
echo "Формат: ".$format."<hr>";
if ($arr = ParseDateTime($datetime, $format))
{
	echo "День:    ".$arr["DD"]."<br>";    // День: 21
	echo "Месяц:   ".$arr["MM"]."<br>";    // Месяц: 1
	echo "Год:     ".$arr["YYYY"]."<br>";  // Год: 2004
	echo "Часы:    ".$arr["HH"]."<br>";    // Часы: 23
	echo "Минуты:  ".$arr["MI"]."<br>";    // Минуты: 44
	echo "Секунды: ".$arr["SS"]."<br>";    // Секунды: 15
}
else echo "Ошибка!";
?>Копировать
```

```
<?
// выведем дату в формате вида "21 января, 2004"
$datetime = "21.01.2004"; // дата задана в формате текущего сайта
// FORMAT_DATETIME - константа содержащая формат времени текущего сайта
$arr = ParseDateTime($datetime, FORMAT_DATETIME);
// 21 января, 2004
echo $arr["DD"]." ".ToLower(GetMessage("MONTH_".intval($arr["MM"])."_S")).", ".$arr["YYYY"];
?>Копировать
```

```
<?
// вывод даты активности элемента информационного блока 
// в произвольном формате
// подключим модуль информационных блоков
if (CModule::IncludeModule("iblock"))
{
	// выберем произвольный элемент информационного блока
	$rsElement = CIBlockElement::GetByID(32675);
	$arElement = $rsElement->Fetch();
	// получим дату активности выбранного элемента
	// выбранную в соответствии с форматом времени текущего сайта
	$date_active = $arElement["ACTIVE_FROM"]; // 28.01.2005
    
	// получим формат времени текущего сайта
	$site_format = CSite::GetDateFormat(); // DD.MM.YYYY HH:MI:SS
	// получим массив описывающий дату активности выбранного элемента
	if ($arr = ParseDateTime($date_active, $site_format))
	{
		/*
		структура полученного массива $arr:
		Array
		(
			[DD] => 28
			[MM] => 1
			[YYYY] => 2005
			[HH] => 0
			[MI] => 0
			[SS] => 0
		)
		*/
		// переведем дату активности в Unix-формат
		$stmp = mktime(
			$arr["HH"], $arr["MI"], $arr["SS"], 
			$arr["MM"], $arr["DD"], $arr["YYYY"]
		);
		// выведем дату активности выбранного элемента в произвольном виде
		// с помощью стандартной PHP функции date
		echo date("d F Y", $stmp); // 28 January 2005
	}
}
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

IsAmPmMode (с версии 11.5.5)

IsAmPmMode
==========

```
IsAmPmMode ()Копировать
```

Определяет используется ли 12-и часовой формат времени. Если *true*, то время выводится в 12-часовом формате времени.

#### Примеры использования

```
if (IsAmPmMode())
{
	echo date("g:i a");
}
	else
{
	echo date("H:i");
}Копировать
```

Новинки документации в соцсетях:
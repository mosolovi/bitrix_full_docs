[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Дата и время](/api_help/main/functions/date/index.php)

MakeTimeStamp (с версии 4.0.6)

MakeTimeStamp
=============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
int
MakeTimeStamp(
	string datetime,
	string format = FORMAT_DATETIME
);Копировать
```

Конвертирует время из строки в Unix-формат.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *datetime* | Исходное время. |
| *format\_type* | Формат времени заданном в параметре *datetime*. В формате допустимы следующие обозначения:  * **YYYY** - год * **MM** - месяц * **DD** - день * **HH** - часы * **MI** - минуты * **SS** - секунды  Необязательный параметр. По умолчанию равен константе  [FORMAT\_DATETIME](/api_help/main/general/constants.php#format_datetime), хранящей текущий формат времени сайта или языка (для административной части). |

### Смотрите также

* [ConvertTimeStamp](/api_help/main/functions/date/converttimestamp.php)
* [AddToTimeStamp](/api_help/main/functions/date/addtotimestamp.php)
* [ParseDateTime](/api_help/main/functions/date/parsedatetime.php)

### Примеры использования

```
<?
// зададим дату
$date = "07.04.2005 11:32:00";
// преобразуем ее в Unix-timestamp
if ($stmp = MakeTimeStamp($date, "DD.MM.YYYY HH:MI:SS"))
{
	// для проверки выведем на экран ту же дату
	// полученную из Unix-timestamp
	echo date("d.m.Y H:i:s", $stmp);
}
else // если функция вернула false то
{
	// выведем сообщение об ошибке
	echo "Некорректная дата!";
}
?>Копировать
```

```
<?
// вывод даты активности элемента информационного блока 
// в произвольном формате
// подключим модуль информационных блоков
if (CModule::IncludeModule("iblock"))
{
	// выберем произвольный элемент информационного блока
	$rsElement = CIBlockElement::GetByID(32675);
	$arElement = $rsElement->Fetch();
	// получим дату активности выбранного элемента
	// выбранную в соответствии с форматом времени текущего сайта
	$date_active = $arElement["ACTIVE_FROM"]; // 28.01.2005
    
	// получим формат времени текущего сайта
	$site_format = CSite::GetDateFormat(); // DD.MM.YYYY HH:MI:SS
	// преобразуем дату в Unix формат
	if ($stmp = MakeTimeStamp($date_active, $site_format))
	{
		// выведем дату активности выбранного элемента в произвольном виде
		// с помощью стандартной PHP функции date
		echo date("d F Y", $stmp); // 28 January 2005
	}
	else // если преобразование безуспешно то
	{
		// выведем сообщение об ошибке
		ShowError("Некорректная дата активности элемента 32675!");
	}
}
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

TruncateText (с версии 3.0.3)

TruncateText
============

```
string
TruncateText(
	string text,
	int Len
);Копировать
```

Отсекает от строки все символы свыше указанной длины. Если отсечение произошло, то к строке справа дописывается многоточие.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *text* | Исходная строка. |
| *Len* | Длина конечной строки. |

#### Смотрите также

* [InsertSpaces](/api_help/main/functions/string/insertspaces.php)

#### Примеры использования

```
<?
$str = "1234567890";
echo TruncateText($str, 7);
// результатом будет строка "1234567..."
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

CheckSerializedData (с версии 9.1.2)

CheckSerializedData
===================

```
CheckSerializedData(
	$str,
	$max_depth = 200,
);Копировать
```

Проверка на валидность серилизованной строки. Всегда, при работе с неизвестным источником серилизованных данных необходимо делать проверку на валидность.
Пример [взлома](https://xakep.ru/2010/04/22/51883/).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| str | Серилизованная строка |
| *max\_depth* | Максимальная вложенность данных объекта или массива. |

#### Примеры использования

```
if (CheckSerializedData($_REQUEST["LIST_DATA"])) {
	$arData = unserialize($_REQUEST["LIST_DATA"]);
} Копировать
```

Новинки документации в соцсетях:
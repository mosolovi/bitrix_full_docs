[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

htmlspecialcharsBack (с версии 3.0.11)

htmlspecialcharsBack
====================

Включить вкладки

Описание и параметры

Примеры использования

### Описание и параметры

```
string
htmlspecialcharsBack(
	string text
);Копировать
```

Переводит текст из HTML-безопасного вида в исходное представление, заменяя в тексте:  

| Исходные символы | После замены |
| --- | --- |
| &lt; | < |
| &gt; | > |
| &quot; | " |
| &amp; | & |

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *text* | Текст для преобразования. |

#### Смотрите также

* [htmlspecialcharsEx](/api_help/main/functions/string/htmlspecialcharsex.php)

### Примеры использования

```
<?
$text = '&quot;если a&gt;b и b&gt;c, то a&gt;c&quot;'
$res = htmlspecialcharsBack($str);
// в переменной $res будет: 
// "если a>b и b>c, то a>c"
?>Копировать
```

Новинки документации в соцсетях:
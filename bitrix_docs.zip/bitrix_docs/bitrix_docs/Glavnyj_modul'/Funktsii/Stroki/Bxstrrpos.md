[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

Bxstrrpos (с версии 4.0.14)

Bxstrrpos
=========

```
function
Bxstrrpos(
	haystack,
	needle
);Копировать
```

Возвращает позицию последнего вхождения строки *needle* в *haystack*. Работает с UTF строками.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| haystack | Стек |
| needle | Строка |

Новинки документации в соцсетях:
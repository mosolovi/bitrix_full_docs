[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

TrimExAll (с версии 3.0.3)

TrimExAll
=========

```
function
TrimExAll(
	str,
	symbol,
);Копировать
```

Удаляет все крайние символы $symbol в строке $str.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| str | Строка, откуда производится удаление |
| symbol | Символы, подлежащие удалению |

Новинки документации в соцсетях:
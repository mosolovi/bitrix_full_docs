[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

htmlspecialcharsEx (с версии 3.2.5)

htmlspecialcharsEx
==================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
string
htmlspecialcharsEx(
	string text
);Копировать
```

Переводит текст в HTML-безопасный вид, заменяя специальные символы их визуальным HTML представлением:  

| Исходные символы | После замены |
| --- | --- |
| < | &lt; |
| > | &gt; |
| " | &quot; |
| &quot; | &amp;quot; |
| &amp; | &amp;amp; |
| &lt; | &amp;lt; |
| &gt; | &amp;gt; |

**Примечание**: в отличии от стандартной PHP функции **htmlspecialchars**, данная функция позволяет задавать в тексте символы в виде: **&код\_символа;**

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *text* | Текст для преобразования. |

### Смотрите также

* [htmlspecialcharsBack](/api_help/main/functions/string/htmlspecialcharsback.php)

### Примеры использования

```
<?
$text = '"если a>b и b>c, то a>c"';
$res = htmlspecialcharsEx($text); 
// в переменной $res будет: 
// &quot;если a&gt;b и b&gt;c, то a&gt;c&quot;
echo $res; 
// на экране будет: 
// "если a>b и b>c, то a>c"
?>Копировать
```

Новинки документации в соцсетях:
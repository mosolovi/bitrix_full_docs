[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

randString

randString
==========

```
string
randString(
	int pass_len = 10,
	pass_chars=false
);Копировать
```

Возвращает строку указанной длины, состоящую из случайных символов. Символами могут быть буквы английского алфавита и цифры. Функция может использоваться например, для генерации пароля.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *pass\_len* | Длина результирующей случайной строки. |  |
| *Набор символов* | набор символов. Необязательный. По умолчанию: abcdefghijklnmopqrstuvwxyzABCDEFGHIJKLNMOPQRSTUVWXYZ01234567­89. может быть массивом классов символов и тогда в результирующую строчку войдет как минимум один символ из каждого класса. Пример:  ``` echo randString(7, array( 	"abcdefghijklnmopqrstuvwxyz", 	"ABCDEFGHIJKLNMOPQRSTUVWXYZ", 	"0123456789", 	"!@#\$%^&*()", ));Копировать ``` | 7.1.0 |

#### Примеры использования

```
<?
$new_password = randString(7);
echo "Новый пароль: ".$new_password;
// выводит строку "Новый пароль: fK4ftTP"
?>Копировать
```

Новинки документации в соцсетях:
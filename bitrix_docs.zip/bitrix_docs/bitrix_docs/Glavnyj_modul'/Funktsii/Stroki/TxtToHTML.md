[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

TxtToHTML (с версии 3.0.3)

TxtToHTML
=========

Включить вкладки

Описание и параметры

Смотрите также

Пример работы функции

### Описание и параметры

```
string
TxtToHTML(
	string text,
	bool make_url = true,
	int max_string = 0,
	string quote_tag_enabled = "N",
	string not_convert_amp = "Y",
	string code_tag_enabled = "N",
	string biu_tags_enabled = "N",
	string quote_table_class = "quotetable",
	string quote_head_class = "tdquotehead",
	string quote_body_class = "tdquote",
	string code_table_class = "codetable",
	string code_head_class = "tdcodehead",
	string code_body_class = "tdcodebody",
	string code_textarea_class = "codetextarea",
	string link_class = "txttohtmllink",
	array  event = array()
);Копировать
```

Конвертирует обычный текст в HTML-код форматирующий исходный текст.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| text | Исходный текст. |
| make\_url | Если значение "true", то - преобразовывать подстроки, которые представляют собой web-адреса (http://... или mailto:), в HTML ссылки. Необязательный параметр. По умолчанию - "true". |
| max\_string | Максимальная длина слова. Все слова длиннее этого параметра разбиваются пробелами. Значение "0" - означает "не разбивать слова". Необязательный параметр. По умолчанию - "0". |
| quote\_tag\_enabled | Если значение - "Y", то спец. тег <QUOTE>...</QUOTE> (цитата) будет преобразован в HTML таблицу (визуально цитата будет обрамлена рамкой). Необязательный параметр. По умолчанию - "N". |
| not\_convert\_amp | Если значение - "Y", то "&" не будет преобразован "&amp;". Необязательный параметр. По умолчанию - "Y". |
| code\_tag\_enabled | Если значение - "Y", то спец. тег <CODE>...</CODE> (код) будет преобразован в HTML элемент textarea, в свою очередь обрамленный таблицей (визуально код будет обрамлен рамкой и выведен в textarea). Необязательный параметр. По умолчанию - "N". |
| biu\_tags\_enabled | Если значение - "Y", то спец. теги <b>...</b>, <i>...</i>, <u>...</u> будут преобразованы в соответствующие им HTML теги. |
| quote\_table\_class | CSS класс на таблицу цитаты (<quote>). Необязательный параметр. По умолчанию - "quotetable". |
| quote\_head\_class | CSS класс на первую ячейку (TD) таблицы цитаты (<quote>). Необязательный параметр. По умолчанию - "tdquotehead". |
| quote\_body\_class | CSS класс на вторую ячейку (TD) таблицы цитаты (<quote>):  ``` <table class="quote_table_class"> 	<tr> 		<td class="quote_head_class"> ...  		</td> 	</tr> 	<tr> 		<td class="quote_body_class"> ...  		</td> 	</tr> </table>Копировать ```  Необязательный параметр. По умолчанию - "tdquote". |
| code\_table\_class | CSS класс на таблицу кода (<code>). Необязательный параметр. По умолчанию - "codetable". |
| code\_head\_class | CSS класс на первую TD таблицы кода (<code>). Необязательный параметр. По умолчанию - "tdcodehead". |
| code\_body\_class | CSS класс на вторую TD таблицы кода (<code>). Необязательный параметр. По умолчанию - "tdcodebody". |
| code\_textarea\_class | CSS класс на textarea в таблице кода (<code>):  ``` <table class="code_table_class"> 	<tr> 		<td class="code_head_class"> ... </td> 	</tr> 	<tr> 		<td class="code_body_class"> 			<textarea class="code_textarea_class"> ...  			</textarea> 		</td> 	</tr> </table>Копировать ```  Необязательный параметр. По умолчанию - "codetextarea". |
| link\_class | CSS класс на ссылках:  ``` <a class="link_class"> ... </a>Копировать ```  Необязательный параметр. По умолчанию - "txttohtmllink". |
| event | В данном массиве можно задать идентификаторы типа события, которое будет фиксироваться при клике на HTML ссылке. Параметр работает, только если  `make_url == true`.  Допустимы следующие ключи данного массива:  * EVENT1 - идентификатор event1 типа события; * EVENT2 - идентификатор event2 типа события; * EVENT3 - идентификатор event3 типа события; * SCRIPT - путь относительно корня к скрипту фиксирующему событие и осуществляющему редирект. |

### Смотрите также

* [HTMLToTxt](/api_help/main/functions/string/htmltotxt.php)

### Пример работы функции

**Вызов:**

```
$text = "
текст текст текст текст 
текст текст текст текст 
длиннноесловодлиннноеслово
<code>код код код</code>
<quote>цитата цитата цитата</quote>
<b>жирный текст</b>
<i>курсив</i>
<u>подчёркнутый</u>
ссылка: http://www.1c-bitrix.ru
email: support@1c-bitrix.ru
";
echo TxtToHTML(
	$text, 
	true, 
	20, 
	"Y", 
	"N", 
	"Y", 
	"Y", 
	"quotetable", 
	"tdquotehead", 
	"tdquote",
	"codetable",
	"tdcodehead",
	"tdcodebody",
	"codetextarea"
);Копировать
```

**Результат:**

```
текст текст текст текст <br>
текст текст текст текст <br>
длиннноесловодлиннн оеслово<br>
<table class='codetable'>
	<tr>
		<td class='tdcodehead'>Код</td>
	</tr>
	<tr>
		<td class='tdcodebody'>
			<textarea class='codetextarea' contentEditable=false cols=60 rows=15 wrap=virtual>код код код</textarea>
		</td>
	</tr>
</table><br>
<table class='quotetable' width='95%' border='0' cellpadding='3' cellspacing='1'>
	<tr>
		<td class='tdquotehead'>Цитата</td>
	</tr>
	<tr>
		<td class='tdquote'>цитата цитата цитата</td>
	</tr>
</table><br>
<b>жирный текст</b><br>
<i>курсив</i><br>
<u>подчёркнутый</u><br>
ссылка: <a class="txttohtmllink" href="http://www.1c-bitrix.ru">http://www.1c-bitrix.ru</a><br>
email: <a class="txttohtmllink" href="mailto:support@1c-bitrix.ru">support@1c-bitrix.ru</a>Копировать
```

**CSS (его предварительно необходимо подключить до вызова функции):**

```
.quotetable, .codetable {width:90%}
.quotetable .tdquotehead, 
.quotetable .tdquote, 
.codetable  .tdcodehead,
.codetable  .tdcodebody,
.codetextarea {padding: 2px; font-family: Arial; font-size:12px; color:#000000}
.quotetable .tdquotehead, 
.codetable  .tdcodehead {font-weight:bold}
.quotetable .tdquote, 
.codetable  .tdcodebody {border: 1px solid Black}
.quotetable .tdquotehead, 
.quotetable .tdquote, 
.codetable  .tdcodehead,
.codetable  .tdcodebody,
.codetextarea {background-color: #FFFFFF}
.codetextarea {
	border: solid 0px; 
	width: 100%;
	overflow: auto;
	scrollbar-shadow-color: #000000; 
	scrollbar-arrow-color:  #000000; 
	scrollbar-base-color:   #000000
}
.codetextarea {
	scrollbar-face-color:       #FFFFFF; 
	scrollbar-highlight-color:  #FFFFFF; 
	scrollbar-track-color:      #FFFFFF; 
	scrollbar-darkshadow-color: #FFFFFF
}Копировать
```

**Визуальное представление (то, что мы увидим на экране монитора):**

текст текст текст текст   
текст текст текст текст   
длиннноесловодлиннн оеслово  

|  |
| --- |
| Код. |
| код код код |

  

|  |
| --- |
| Цитата. |
| цитата цитата цитата. |

  
**жирный текст**  
*курсив*  
подчёркнутый  
ссылка: <http://www.1c-bitrix.ru>  
email: [support@1c-bitrix.ru](mailto:support@1c-bitrix.ru)

Новинки документации в соцсетях:
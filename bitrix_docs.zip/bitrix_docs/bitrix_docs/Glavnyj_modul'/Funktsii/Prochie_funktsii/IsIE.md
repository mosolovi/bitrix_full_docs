[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

IsIE (с версии 3.0.10)

IsIE
====

```
bool
IsIE()Копировать
```

Возвращает "true", если текущий браузер посетителя является браузером "MS Internet Explorer", в противном случае - "false".

#### Параметры функции

Без параметров.

#### Примеры использования

```
<?
if (IsIE()) echo "Вы пользуетесь MS Internet Explorer";
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

bitrix\_sessid (с версии 4.0.8)

bitrix\_sessid
==============

```
string
bitrix_sessid(
);Копировать
```

#### Возвращаемое значение

Возвращает идентификатор сессии, предварительно обработанный функцией md5.

Новинки документации в соцсетях:
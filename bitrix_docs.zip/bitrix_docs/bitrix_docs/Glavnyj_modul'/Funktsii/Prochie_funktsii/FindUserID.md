[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

FindUserID (с версии 3.3.10)

FindUserID
==========

Включить вкладки

Описание и параметры

Примеры использования

### Описание и параметры

```
bool
FindUserID(
	string tag_name, 
	string tag_value
	string user_name = "",
	string form_name = "form1", 
	string tag_size = "3", 
	string tag_maxlength = "",
	string button_title = "...",
	string tag_class = "typeinput",
	string button_class = "tablebodybutton",
	string search_page = "/bitrix/admin/user_search.php"
);Копировать
```

Выводит ряд HTML элементов, позволяющих задать ID пользователя и рядом с этим полем ввода получить данные пользователя. Также
выводится кнопка, ведущая на страницу поиска пользователя.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *tag\_name* | Имя поля для ввода ID пользователя:  `<input type="text" name="tag_name" ...>` |
| *tag\_value* | Значение поля для ввода ID пользователя:  `<input type="text" value="tag_value" ...>` |
| *user\_name* | ID, логин, имя и фамилия пользователя, выводимые рядом с полем для ввода ID пользователя, сразу же после загрузки страницы.   Необязательный параметр. По умолчанию - "". |
| *form\_name* | Имя формы, в которой находится поле для ввода ID пользователя.   Необязательный параметр. По умолчанию - "form1". |
| *tag\_size* | Ширина поля для ввода ID пользователя.  `<input type="text" size="tag_size" ...>`   Необязательный параметр. По умолчанию - "3". |
| *tag\_maxlength* | Максимальное количество символов в поле для ввода ID пользователя:  `<input type="text" maxlength="tag_maxlength" ...>`   Необязательный параметр. По умолчанию - "" (не ограничено). |
| *button\_title* | Подпись на кнопке ведущей на страницу поиска пользователя:  `<input type="button" value="button_title" ...>`   Необязательный параметр. По умолчанию - "...". |
| *tag\_class* | CSS класс для поля ввода ID пользователя:  `<input type="input" class="tag_class" ...>`   Необязательный параметр. По умолчанию - "typeinput". |
| *button\_class* | CSS класс для кнопки ведущей на страницу поиска пользователя:  `<input type="button" class="button_class" ...>`   Необязательный параметр. По умолчанию - "tablebodybutton". |
| *search\_page* | Путь относительно корня на страницу поиска пользователя.  Необязательный параметр. По умолчанию - "/bitrix/admin/user\_search.php" (административная страница). |

### Примеры использования

```
<form name="form1">
<?
$name = "[<a href=\"/bitrix/admin/user_edit.php?lang=".language_id."&id=".
$USER_ID."\">".$USER_ID."</a>] (".$LOGIN.") ".$NAME;		
echo FindUserID("USER_ID", $USER_ID, $name, 
"form1", "3", "", "...", "inputtext", "inputbodybutton");
?>
</form>Копировать
```

Новинки документации в соцсетях:
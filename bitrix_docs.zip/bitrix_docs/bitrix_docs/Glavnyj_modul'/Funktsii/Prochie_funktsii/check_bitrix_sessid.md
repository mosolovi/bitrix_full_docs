[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

check\_bitrix\_sessid (с версии 4.0.8)

check\_bitrix\_sessid
=====================

```
bool
check_bitrix_sessid()(
	$varname='sessid'
)Копировать
```

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| varname | Идентификатор сессии |

#### Возвращаемое значение

Возвращает true, если верно условие `$_REQUEST[$varname] == bitrix_sessid()`, иначе false.

#### Примеры использования

```
if($arResult["Perm"]>=BLOG_PERMS_MODERATE && intval($_GET["delete_comment_id"])>0 && check_bitrix_sessid())
{
	/*Удаление комментария*/
} Копировать
```

Новинки документации в соцсетях:
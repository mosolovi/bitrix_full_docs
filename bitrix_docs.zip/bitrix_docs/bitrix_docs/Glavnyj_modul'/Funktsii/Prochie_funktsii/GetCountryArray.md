[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

GetCountryArray (с версии 3.0.6)

GetCountryArray
===============

Включить вкладки

Описание и параметры

Примеры

### Описание и параметры

```
array
GetCountryArray(
	string language_id = LANGUAGE_ID
)Копировать
```

Возвращает массив стран с названиями на заданном языке. Формат возвращаемого массива позволяет его использовать в функциях [SelectBoxFromArray](/api_help/main/functions/html/selectboxfromarray.php), [SelectBoxMFromArray](/api_help/main/functions/html/selectboxmfromarray.php) без предварительной подготовки.

**Примечание**. Массив стран задается в файлах **/bitrix/modules/main/lang/***language\_id***/tools.php**.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *language\_id* | Идентификатор языка в котором необходимо вернуть названия стран. Необязательный параметр. По умолчанию - [LANGUAGE\_ID](/api_help/main/general/constants.php#language_id) (текущий язык). |

### Примеры

#### Пример возвращаемого массива:

```
Array
(
	[reference_id] => Array
		(
			[0] => 16
			[1] => 17
			[2] => 2
			[3] => 18
			...
		),
	[reference] => Array
		(
			[0] => Австралия
			[1] => Австрия
			[2] => Азербайджан
			[3] => Албания
			...
		)
)Копировать
```

#### Пример использования:

```
<?
// выведем выпадающий список стран
echo SelectBoxFromArray(
	"COUNTRY_ID", 
	<b>GetCountryArray</b>(), 
	$COUNTRY_ID, 
	"< выберите страну >"
);
?>Копировать
```

Новинки документации в соцсетях:
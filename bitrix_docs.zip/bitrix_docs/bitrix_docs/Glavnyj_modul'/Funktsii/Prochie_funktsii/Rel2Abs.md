[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

Rel2Abs (с версии 3.0.3)

Rel2Abs
=======

```
string
Rel2Abs(
	string cur_dir,
	string rel_path
);Копировать
```

Возвращает путь относительно заданного каталога *cur\_dir*. Если *rel\_path* пустой, то функция возвращает **false**. Если *rel\_path* является абсолютным путем (т.е. начинается с "/" или имеет вид "C:\"), то параметр *cur\_dir* игнорируется. Если в *rel\_path* попытаться с помощью "../" подняться выше корня, то функция блокирует эту попытку удалив все промежуточные подъемы. Например: по запросу `/test/../../test.php` она вернет `/test/test.php`.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *cur\_dir* | Каталог, относительно которого задается путь *rel\_path*. |
| *rel\_path* | Относительный путь. |

#### Примеры использования

```
<?
echo Rel2Abs("/site/", "/temp/index.php");	// /temp/index.php
echo Rel2Abs("/site/", "temp/index.php");	// /site/temp/index.php
echo Rel2Abs("/site/temp/", "../index.php");	// /site/index.php
echo Rel2Abs("/site/temp/", "../../index.php");	// /index.php
?>Копировать
```

Новинки документации в соцсетях:
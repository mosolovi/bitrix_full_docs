[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

bxmail (с версии 7.1.3)

bxmail
======

```
bxmail(
	string to,
	string subject,
	string message,
	string additional_headers = "",
	string additional_parameters = ""
);Копировать
```

Проверяет существование функции custom\_mail и если такая функция есть, то bxmail вызывает ее со всеми параметрами и возвращает ее результат.

Иначе вызывается встроенная php функция mail.

Данная функция вызывается из главного модуля при отправке почтовых событий, а так же из модуля подписки при отправке выпусков. Это позволяет переопределить обработчик всех писем отправляемых БУС.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *to* | Получатель. |
| *subject* | Заголовок письма. |
| *message* | Тело письма. |
| *additional\_headers* | Дополнительные заголовки. |
| *additional\_parameters* | Дополнительные параметры для php функции mail(). |

#### Возвращаемое значение

Возвращается результат работы функции custom\_mail или mail.

#### Смотрите также

- [mail](http://ru2.php.net/manual/en/function.mail.php)

Новинки документации в соцсетях:
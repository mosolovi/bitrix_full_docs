[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

GetWhoisLink (с версии 3.3.0)

GetWhoisLink
============

```
string
GetWhoisLink(
	string ip,
	string link_class = 
);Копировать
```

Возвращает ссылку на один из сайтов службы Whois для получения данных по заданному IP адресу.

Формат возвращаемой ссылки:  
`<a href="http://www.whois.sc/ip" class="link_class">ip</a>`

**#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *ip* | IP адрес в формате XXX.XXX.XXX.XXX для которого необходимо сформировать ссылку. |
| *class* | CSS класс ссылки. |

#### Примеры использования

```
<?
echo GetWhoisLink("210.49.16.111");
?>Копировать
```**

**Новинки документации в соцсетях:**
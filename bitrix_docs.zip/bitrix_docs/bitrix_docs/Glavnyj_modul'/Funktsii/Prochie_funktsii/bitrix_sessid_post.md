[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

bitrix\_sessid\_post (с версии 4.0.8)

bitrix\_sessid\_post
====================

```
string
bitrix_sessid_post(
	$varname='sessid'
)Копировать
```

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| varname | Идентификатор сессии |

#### Возвращаемое значение

Возвращает строку вида `<input type="hidden" name="$varname" id="$varname" value="идентификатор сесии" />`.

#### Примеры использования

Передача идентификатора сессии в форме

```
<form method="post" action="/news/add.php">
<?=bitrix_sessid_post()?>
Title: <input type="text" name="NAME" size="40" maxlength="255" value="">
</form>Копировать
```

Новинки документации в соцсетях:
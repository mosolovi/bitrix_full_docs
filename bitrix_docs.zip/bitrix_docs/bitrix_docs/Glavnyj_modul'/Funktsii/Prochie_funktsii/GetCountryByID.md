[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

GetCountryByID (с версии 3.0.7)

GetCountryByID
==============

```
string
GetCountryByID(
	int cid,
	string lang = LANGUAGE_ID
)Копировать
```

Возвращает название страны на заданном языке по ее коду.

**Примечание**. Цифровые коды стран вы можете посмотреть в файле **/bitrix/modules/main/lang/***language\_id***/tools.php**.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *id* | Цифровой код страны. |  |
| *lang* | Идентификатор языка в котором необходимо вернуть название страны. Необязательный параметр. По умолчанию - [LANGUAGE\_ID](/api_help/main/general/constants.php#language_id) (текущий язык). | 4.0.6 |

#### Примеры использования

```
<?
echo GetCountryByID(34, "ru"); // Бразилия
?>Копировать
```

Новинки документации в соцсетях:
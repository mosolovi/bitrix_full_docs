[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

roundEx (с версии 3.0.3)

roundEx
=======

```
function 
roundEx(
	value,
	prec=0
);Копировать
```

Округляет сверху значение $value до $prec знаков после запятой.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| value | Округляемое значение |
| *prec* | Число знаков запятой, до которых происходит округление. |

Новинки документации в соцсетях:
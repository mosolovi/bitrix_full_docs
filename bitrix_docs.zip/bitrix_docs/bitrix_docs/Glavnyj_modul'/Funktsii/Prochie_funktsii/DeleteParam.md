[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

DeleteParam (с версии 3.0.3)

DeleteParam
===========

```
string
DeleteParam(
	array remove_params
);Копировать
```

На основе стандартного массива $HTTP\_GET\_VARS формирует строку параметров, удаляя из нее те параметры, имена которых указаны в *remove\_params*.

В новом ядре D7 обращайтесь к методам:

* [Bitrix\Main\Web\Uri::deleteParams](http://dev.1c-bitrix.ru/api_d7/bitrix/main/web/uri/deleteparams.php),
* [Bitrix\Main\Web\Uri::getUri](http://dev.1c-bitrix.ru/api_d7/bitrix/main/web/uri/geturi.php)

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *remove\_params* | Массив имен параметров, которые необходимо удалить из результирующей строки. |

#### Примеры использования

```
<?
// Сформируем ссылку на произвольную страницу
// со всеми текущими GET параметрами, 
// при этом заменив (или добавив если их не было) 
// параметры "page" и "order"
?>
<a href="page.php?page=1&order=asc&<?=DeleteParam(array("page","order"))?>">ссылка</a>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

check\_email

check\_email
============

Включить вкладки

Описание и параметры

Примеры использования

### Описание и параметры

```
bool
check_email(
	string email,
	bool Strict = false
);Копировать
```

Проверяет E-Mail адрес на синтаксическую корректность. Возвращает "true", если адрес синтаксически корректен, в противном случае - "false".

**Примечание**. Email проверяется согласно RFC822, то есть, к примеру, test@test - абсолютно правильный с точки зрения данной функции адрес. Поэтому данная функция не подходит для проверки формата адреса электронной почты в традиционном понимании.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *email* | Проверяемый E-Mail адрес. |  |
| *Strict* | Необязательный. По умолчанию: "false". При bStrict = true  ``` echo (check_email("Bitrix ")) ? "OK!" : "Error!"; // Error!Копировать ``` | 10.0.3 |

### Примеры использования

```
<?
echo (check_email("Bitrix <admin@bitrix.ru>")) ? "OK!" : "Error!"; // OK
echo (check_email("mail@server.com")) ? "OK!" : "Error!"; // OK
echo (check_email("admin@bi$trix.ru")) ? "OK!" : "Error!"; // ERROR
?>Копировать
```

Новинки документации в соцсетях:
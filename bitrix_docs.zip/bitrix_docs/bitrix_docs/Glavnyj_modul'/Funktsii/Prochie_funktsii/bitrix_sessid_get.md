[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Прочие функции](/api_help/main/functions/other/index.php)

bitrix\_sessid\_get (с версии 4.0.8)

bitrix\_sessid\_get
===================

```
string
bitrix_sessid_get(
	$varname='sessid'
)Копировать
```

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| varname | Идентификатор сессии |

#### Возвращаемое значение

Возвращает строку вида
$varname=идентификатор сессии



Например, sessid=d3f742dc1453da22e9e08e113ccad5b8
для использования в ссылках, предварительно обработанную функцией md5.

#### Примеры использования

Передача идентификатора в ссылке.

```
<a href="/news/detail.php?ID=123&delete=Y&<?=bitrix_sessid_get()?>">Удалить</a>Копировать
```

Новинки документации в соцсетях:
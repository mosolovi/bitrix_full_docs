[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

UnRegisterModuleDependences (с версии 3.0.1)

UnRegisterModuleDependences
===========================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
UnRegisterModuleDependences(
	string from_module_id,
	string MESSAGE_ID,
	string to_module_id,
	string to_class = "",
	string to_method = "",
	string TO_PATH="",
	array TO_METHOD_ARG = array()
);Копировать
```

Удаляет регистрационную запись обработчика события.

Аналог метода в новом ядре: *Bitrix\Main\EventManager::unRegisterEventHandler*.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *from\_module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php) который инициирует событие. |  |
| *MESSAGE\_ID* | Идентификатор события. |  |
| *to\_module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php) содержащий функцию-обработчик события. |  |
| *to\_class* | Класс принадлежащий модулю *module*, метод которого является функцией-обработчиком события. Необязательный параметр. По умолчанию - "". |  |
| *to\_method* | Метод класса *to\_class* являющийся функцией-обработчиком события. Необязательный параметр. По умолчанию - "". |  |
| *TO\_PATH* | Необязательный параметр, по умолчанию пустой. | 5.1.0 |
| *TO\_METHOD\_ARG* | Массив аргументов для функции-обработчика событий.   Необязательный параметр. | 8.5.0 |

### Смотрите также

* [Связи и взаимодействие модулей](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=2825)
* [RegisterModuleDependences](/api_help/main/functions/module/registermoduledependences.php)

### Примеры использования

```
<?
UnRegisterModuleDependences("main", "OnUserDelete", "forum", "CForum", "OnUserDelete");
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

ExecuteModuleEventEx (С версии 8.6.2)

ExecuteModuleEventEx
====================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
mixed
ExecuteModuleEventEx(
	$arEvent, 
	$arParams = array()
);Копировать
```

Запускает обработчик события на выполнение.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *Event* | Структура данных описывающая один обработчик события. Массив описаний обработчиков возвращает метод [GetModuleEvents](/api_help/main/functions/module/getmoduleevents.php) |  |
| *Params* | Перечень параметров передаваемых в обработчики события. Этот перечень определяется автором события и индивидуален для каждого события. Параметры могут передаваться как по ссылке так и по значению. Параметры переданные по значению могут быть изменены внутри обработчика. Для передачи параметра по значению в массив должна быть добавлена ссылка на него. |  |

**Получение списка обработчиков события и вызов их:**

```
foreach (GetModuleEvents("мой_модуль", "МоеСобытие", true) as $arEvent)
{
	ExecuteModuleEventEx($arEvent, array(параметры));
}Копировать
```

**Получение списков обработчика с возможностью отмены работы метода, внутри которого вызываются события:**

```
foreach (GetModuleEvents("мой_модуль", "МоеСобытие", true) as $arEvent)
{
	if (ExecuteModuleEventEx($arEvent, array(параметры))===false)
		return false;
}Копировать
```

#### Примечание

Для вызова обработчиков функция [ExecuteModuleEvent](/api_help/main/functions/module/executemoduleevent.php) не поддерживается с версии 10.0.0.

### Смотрите также

* [GetModuleEvents](/api_help/main/functions/module/getmoduleevents.php)

### Примеры использования

```
ExecuteModuleEventEx($arEvent, array($ID, &$arFields))
Копировать
```

В этом случае обработчик получит два параметра - $ID и $arFields. Значения второго он может менять, так как передан по ссылке.

Новинки документации в соцсетях:
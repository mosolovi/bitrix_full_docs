[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

CheckVersion (с версии 3.0.5)

CheckVersion
============

```
bool
CheckVersion(
	string version1,
	string version2
);Копировать
```

Сравнивает версии в форматах **XX.XX.XX**. Возвращает true, если первая версия, переданная в параметре *version1*, больше или равна второй версии, переданной в параметре *version2*, иначе - false.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *version1* | Первая версия в формате "XX.XX.XX" |
| *version2* | Вторая версия в формате "XX.XX.XX" |

#### Примеры использования

```
<?
$ver1 = "3.0.15";
$ver2 = "4.0.0";
$res = CheckVersion($ver1, $ver2);
echo ($res) ? $ver1." >= ".$ver2 : $ver1." < ".$ver2; 
// результат: 3.0.15 < 4.0.0
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

RegisterModule (с версии 3.0.1)

RegisterModule
==============

```
RegisterModule(
	string mоdule_id
);Копировать
```

Регистрация модуля в системе. Как правило регистрация модуля является неотъемлемой частью процесса [инсталляции модуля](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=3475).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php). |

#### Смотрите также

* [UnRegisterModule](/api_help/main/functions/module/unregistermodule.php)
* [CModule::DoInstall](/api_help/main/reference/cmodule/doinstall.php)

#### Примеры использования

```
<?
// файл /bitrix/modules/statistic/install/step2.php 
RegisterModule("statistic");
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

AddEventHandler (с версии 4.0.6)

AddEventHandler
===============

Включить вкладки

Описание и параметры

Аналоги в ядре D7

Смотрите также

Примеры использования

### Описание и параметры

```
AddEventHandler(
	string from_module_id,
	string MESSAGE_ID,
	mixed callback,
	int sort = 100,
	mixed full_path = false
);Копировать
```

Регистрирует произвольный обработчик *callback* события *MESSAGE\_ID* модуля *from\_module\_id*. Если указан полный путь к файлу с обработчиком *full\_path*, то он будет автоматически подключен перед вызовом обработчика. Вызывается на каждом хите и работает до момента окончания работы скрипта.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *from\_module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php) который будет инициировать событие. |
| *MESSAGE\_ID* | Идентификатор события. |
| *callback* | Название функции обработчика. Если это метод класса, то массив вида Array(класс(объект), название метода). |
| *sort* | Очередность (порядок), в котором выполняется данный обработчик (обработчиков данного события может быть больше одного). Необязательный параметр, по умолчанию равен 100. |
| *full\_path* | Полный путь к файлу для подключения при возникновении события перед вызовом *callback*. |

#### Примечание

Все зарегистрированные обработчики хранятся в глобальной переменной $MAIN\_MODULE\_EVENTS.

### Аналоги в ядре D7

У функции есть [аналоги в ядре D7](https://dev.1c-bitrix.ru/api_d7/bitrix/main/EventManager/index.php).

Обратите внимание, порядок параметров в них отличается: подключение файла выполняется перед сортировкой.

  

* `Bitrix\Main\EventManager::addEventHandler` — регистрирует обработчик события. В качестве аргумента передается объект события Bitrix\Main\Event.

  ```
  EventManager::addEventHandler(
      $fromModuleId,
      $eventType,
      $callback,
      $includeFile = false,
      $sort = 100
  )
  Копировать
  ```
* `Bitrix\Main\EventManager::addEventHandlerCompatible` — регистрирует обработчик события со старыми аргументами.

  ```
  EventManager::addEventHandlerCompatible(
      $fromModuleId,
      $eventType,
      $callback,
      $includeFile = false,
      $sort = 100
  )
  Копировать
  ```

### Смотрите также

* [Связи и взаимодействие модулей](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=2825)
* [RegisterModuleDependences](/api_help/main/functions/module/registermoduledependences.php)

### Примеры использования

```
<?
// скрипт в файле /bitrix/php_interface/init.php
AddEventHandler("main", "OnBeforeUserLogin", Array("MyClass", "BeforeLogin"));
class MyClass
{
	function BeforeLogin(&$arFields)
	{
		if(strtolower($arFields["LOGIN"])=="guest")
		{
			global $APPLICATION;
			$APPLICATION->throwException("Пользователь с именем входа Guest не может быть авторизован.");
			return false;
		}
	}
}
?>Копировать
```

Новинки документации в соцсетях:
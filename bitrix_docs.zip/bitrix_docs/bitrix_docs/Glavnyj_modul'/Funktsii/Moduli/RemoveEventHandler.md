[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

RemoveEventHandler (с версии 6.5.4)

RemoveEventHandler
==================

```
function
ClassName::MethodName(
	FROM_MODULE_ID,
	MESSAGE_ID,
	iEventHandlerKey = default value
);Копировать
```

Функция отзывает зарегистрированный обработчик.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| FROM\_MODULE\_ID | Идентификатор модуля |
| *MESSAGE\_ID* | Идентификатор события |
| *iEventHandlerKey* | Идентификатор, возвращенный функцией AddEventHandler. |

Новинки документации в соцсетях:
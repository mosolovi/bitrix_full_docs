[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

GetModuleEvents (с версии 3.0.1)

GetModuleEvents
===============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
CDBResult
GetModuleEvents(
	string module_id, 
	string event_id,
	bReturnArray = false
);Копировать
```

Возвращает список обработчиков события *event\_id* модуля *module\_id*
в виде объекта класса [CDBResult](/api_help/main/reference/cdbresult/index.php).

Аналог метода в новом ядре: *Bitrix\Main\EventManager::findEventHandlers*.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php). |  |
| *event\_id* | Идентификатор события. |  |
| *ReturnArray* | Необязательный. По умолчанию "false". Рекомендуется использовать "true". В этом случае вернёт массив параметров, а не [CDBResult](/api_help/main/reference/cdbresult/index.php). | 10.0.11 |

### Смотрите также

* [ExecuteModuleEvent](/api_help/main/functions/module/executemoduleevent.php)

### Примеры использования

```
<?
// проверка возможности удаления форума
// флаг запрещающий или разрешающий удалять форум
$bCanDelete = true;
// получим данные по всем обработчикам события "OnBeforeForumDelete"
// принадлежащего модулю с идентификатором "forum"
$rsEvents = GetModuleEvents("forum", "OnBeforeForumDelete");
while ($arEvent = $rsEvents->Fetch())
{
	// запустим на выполнение очередной обработчик события "OnBeforeForumDelete"
	// если функция-обработчик возвращает false, то
	if (ExecuteModuleEvent($arEvent, $del_id)===false)
	{
		// запрещаем удалять форум
		$bCanDelete = false;
		break;
	}
}
?>Копировать
```

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

RegisterModuleDependences (с версии 3.0.1)

RegisterModuleDependences
=========================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
RegisterModuleDependences(
	string from_module_id,
	string MESSAGE_ID,
	string to_module_id,
	string to_class = "",
	string to_method = "",
	int sort = 100,
	TO_PATH="",
	TO_METHOD_ARG = array()
);Копировать
```

Регистрирует обработчик события. Выполняется один раз (при установке модуля) и этот обработчик события действует до момента вызова события **UnRegisterModuleDependences**.

Аналог функции в новом ядре: [Bitrix\Main\EventManager::registerEventHandler](https://dev.1c-bitrix.ru/api_d7/bitrix/main/EventManager/index.php).

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *from\_module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php), который будет инициировать событие. |  |
| *MESSAGE\_ID* | Идентификатор события. |  |
| *to\_module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php), содержащий функцию-обработчик события. |  |
| *to\_class* | Класс принадлежащий модулю *module*, метод которого является функцией-обработчиком события.   Необязательный параметр. По умолчанию - "" (будет просто подключен файл /bitrix/modules/*to\_module\_id*/include.php). |  |
| *to\_method* | Метод класса *to\_class* являющийся функцией-обработчиком события.   Необязательный параметр. По умолчанию - "" (будет просто подключен файл /bitrix/modules/*to\_module\_id*/include.php). |  |
| *sort* | Очередность (порядок), в котором выполняется данный обработчик (обработчиков данного события может быть больше одного).   Необязательный параметр, по умолчанию равен 100. | 3.0.10 |
| *TO\_PATH* | Необязательный параметр, по умолчанию пустой. Подключает файл по указанному пути (с функцией обработчика) без подключения модуля. Это позволяет создавать более экономные обработчики. | 5.1.0 |
| *TO\_METHOD\_ARG* | Массив аргументов для функции-обработчика событий.   Необязательный параметр. | 8.5.0 |

### Смотрите также

* [Связи и взаимодействие модулей](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=2825)
* [UnRegisterModuleDependences](/api_help/main/functions/module/unregistermoduledependences.php)

### Примеры использования

```
<?
// Для того, чтобы при удалении пользователя сайта 
// производилась соответствующая очистка данных форума, 
// при установке форума выполняется регистрация нового 
// обработчика события "OnUserDelete" модуля main. 
// Этим обработчиком является метод OnUserDelete класса CForum модуля forum.
RegisterModuleDependences("main", "OnUserDelete", "forum", "CForum", "OnUserDelete");
?>Копировать
```

Новинки документации в соцсетях:
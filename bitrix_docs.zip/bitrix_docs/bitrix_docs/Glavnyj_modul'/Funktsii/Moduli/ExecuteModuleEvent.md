[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

ExecuteModuleEvent (с версии 3.0.1, устарел с 10.0.0)

ExecuteModuleEvent
==================

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
mixed
ExecuteModuleEvent(
	array event,
	mixed param1 = NULL,
	mixed param2 = NULL,
	mixed param3 = NULL,
	mixed param4 = NULL,
	mixed param5 = NULL,
	mixed param6 = NULL,
	mixed param7 = NULL,
	mixed param8 = NULL,
	mixed param9 = NULL,
	mixed param10 = NULL
);Копировать
```

Запускает обработчик события на выполнение. Возвращает то значение, которое возвращает конкретный обработчик события.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *event* | Массив описывающий одну регистрационную запись хранящую связь между событием и обработчиком этого события (подобные записи хранятсяв таблице b\_module\_to\_module). Ключи данного массива:  * **ID** - ID записи * **TIMESTAMP\_X** - время изменения записи * **SORT** - сортировка * **FROM\_MODULE\_ID** - какой модуль инициализирует событие * **MESSAGE\_ID** - идентификатор события * **TO\_MODULE\_ID** - какой модуль содержит обработчик события * **TO\_CLASS** - какой класс содержит обработчик события * **TO\_METHOD** - метод класса являющийся по сути обработчиком события |  |
| *param1, param2,  ... , param10* | Произвольный набор значений, которые передаются в качестве параметров в обработчик события. | 4.0.6 |

### Смотрите также

* [GetModuleEvents](/api_help/main/functions/module/getmoduleevents.php)

### Примеры использования

```
<?
// проверка возможности удаления форума
// флаг запрещающий или разрешающий удалять форум
$bCanDelete = true;
// получим данные по всем обработчикам события "OnBeforeForumDelete"
// принадлежащего модулю с идентификатором "forum"
$rsEvents = GetModuleEvents("forum", "OnBeforeForumDelete");
while ($arEvent = $rsEvents->Fetch())
{
	// запустим на выполнение очередной обработчик события "OnBeforeForumDelete"
	// если функция-обработчик возвращает false, то
	if (ExecuteModuleEvent($arEvent, $del_id)===false)
	{
		// запрещаем удалять форум
		$bCanDelete = false;
		break;
	}
}
?>Копировать
```

Новинки документации в соцсетях:
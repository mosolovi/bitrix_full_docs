[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

IsModuleInstalled (с версии 3.0.1)

IsModuleInstalled
=================

```
bool
IsModuleInstalled(
	string module_id
);Копировать
```

Проверяет установлен ли модуль. Возвращает "true", если модуль установлен. Иначе - "false".

**Примечание**. Для использования функций и классов того или иного модуля, его необходимо предварительно подключить с помощью функции [CModule::IncludeModule](/api_help/main/reference/cmodule/includemodule.php).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php). |

#### Смотрите также

* [CModule::IsInstalled](/api_help/main/reference/cmodule/isinstalled.php)
* [CModule::IncludeModule](/api_help/main/reference/cmodule/includemodule.php)

#### Примеры использования

```
<?
if (IsModuleInstalled("iblock")):
	echo "Модуль информационных блоков установлен";
endif;
?>Копировать
```

Новинки документации в соцсетях:
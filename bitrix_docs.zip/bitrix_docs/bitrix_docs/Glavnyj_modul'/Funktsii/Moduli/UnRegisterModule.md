[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

UnRegisterModule (с версии 3.0.1)

UnRegisterModule
================

```
UnRegisterModule(
	string module_id
);Копировать
```

Удаляет регистрационную запись, а также все настройки модуля из базы данных. Как правило удаление регистрационной записи модуля является неотъемлемой частью процесса [деинсталляции модуля](https://dev.1c-bitrix.ru/learning/course/index.php?COURSE_ID=43&LESSON_ID=3475).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *module\_id* | [Идентификатор модуля](/api_help/main/general/identifiers.php). |

#### Смотрите также

* [RegisterModule](/api_help/main/functions/module/registermodule.php)
* [CModule::DoUninstall](/api_help/main/reference/cmodule/douninstall.php)

#### Примеры использования

```
<?
// файл /bitrix/modules/statistic/install/unstep2.php 
UnRegisterModule("statistic");
?>Копировать
```

Новинки документации в соцсетях:
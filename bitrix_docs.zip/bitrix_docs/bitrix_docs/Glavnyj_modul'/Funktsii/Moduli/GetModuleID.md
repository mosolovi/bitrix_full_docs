[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Модули](/api_help/main/functions/module/index.php)

GetModuleID (с версии 3.0.3)

GetModuleID
===========

```
string
GetModuleID(
	string path
);Копировать
```

Возвращает [идентификатор модуля](/api_help/main/general/identifiers.php), которому принадлежит файл.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *path* | Путь к файлу лежащему в каталоге **/bitrix/modules/**. |

#### Примеры использования

```
<?
echo GetModuleID("/bitrix/modules/main/include.php"); // main
?>Копировать
```

Новинки документации в соцсетях:
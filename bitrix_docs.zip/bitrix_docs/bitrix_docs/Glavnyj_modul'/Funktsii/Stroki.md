[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Строки](/api_help/main/functions/string/index.php)

Обзор функций

Обзор функций
=============

Функции для обработки строк и текста:

| Метод | Описание | С версии |
| --- | --- | --- |
| [TxtToHTML](/api_help/main/functions/string/txttohtml.php) | Конвертирует обычный текст в HTML-код форматирующий исходный текст. | 3.0.3 |
| [HTMLToTxt](/api_help/main/functions/string/htmltotxt.php) | Преобразует исходный HTML-код в обычный текст путём удаления тегов или замены их на эквивалентное текстовое форматирование. | 3.0.3 |
| [TruncateText](/api_help/main/functions/string/truncatetext.php) | Отсекает от строки все символы свыше указанной длины. Если отсечение произошло, то к строке справа дописывается многоточие. | 3.0.3 |
| [InsertSpaces](/api_help/main/functions/string/insertspaces.php) | Разбивает длинные слова тексте. Возвращает текст в котором максимальная длина каждого слова не превышает заданной длины. | 3.0.3 |
| [RandString](/api_help/main/functions/string/randstring.php) | Возвращает строку указанной длины, состоящую из случайных символов. | 3.0.3 |
| [ToUpper](/api_help/main/functions/string/toupper.php) | Преобразует символы исходной строки в верхний регистр. | 3.0.3 |
| [ToLower](/api_help/main/functions/string/tolower.php) | Преобразует символы исходной строки в нижний регистр. | 4.0.6 |
| [htmlspecialcharsEx](/api_help/main/functions/string/htmlspecialcharsex.php) | Переводит текст в HTML-безопасный вид, заменяя специальные символы их визуальным HTML представлением. | 3.2.5 |
| [htmlspecialcharsBack](/api_help/main/functions/string/htmlspecialcharsback.php) | Переводит текст из HTML-безопасного вида в исходное представление. | 3.0.11 |
| [utf8win1251](/api_help/main/functions/string/utf8win1251.php) | Конвертирует строку из кодировки UTF-8 в Windows-1251. | 4.0.5 |
| [TrimEx](/api_help/main/functions/string/trimex.php) | Удаляет из строки символ с заданной стороны. | 3.0.3 |
| [TrimExAll](/api_help/main/functions/string/trimexall.php) | Удаляет все крайние символы. | 3.0.3 |
| [Bxstrrpos](/api_help/main/functions/string/bxstrrpos.php) | Возвращает позицию последнего вхождения строки. | 4.0.14 |
| [CheckSerializedData](/api_help/main/functions/string/checkserializeddata.php) | Проверка на валидность серилизованной строки. | 9.1.2 |

Новинки документации в соцсетях:
[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

RewriteFile (с версии 3.0.3)

RewriteFile
===========

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
bool
RewriteFile(
	string abs_path,
	string content
);Копировать
```

Записывает в файл новое содержимое. Возвращает "true" в случае удачной записи в файл, иначе - "false".

Аналог функции в новом ядре D7: [Bitrix\Main\IO\File::putFileContents](http://dev.1c-bitrix.ru/api_d7/bitrix/main/io/file/putfilecontents.php).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *abs\_path* | Абсолютный путь к файлу, который необходимо перезаписать. |
| *content* | Новое содержимое файла. |

#### Примечание

Если в абсолютном пути файла будут указаны несуществующие директории, то указанный метод их создаст. Например, в:

```
RewriteFile($_SERVER["DOCUMENT_ROOT"]."/ru/index.php", $content);Копировать
```

если папки `/ru/` не существует, то она будет создана.

### Смотрите также

* [CFile::SaveFile](/api_help/main/reference/cfile/savefile.php)
* [CMain::SaveFileContent](/api_help/main/reference/cmain/savefilecontent.php)

### Примеры использования

```
<?
// перезапишем файл /ru/index.php
$content = '
	<?
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
	$APPLICATION->SetTitle("Заголовок страницы");
	?>
	<?
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
	?>
';
RewriteFile($_SERVER["DOCUMENT_ROOT"]."/ru/index.php", $content);
?>Копировать
```

Новинки документации в соцсетях:
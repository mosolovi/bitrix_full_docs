[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

DeleteDirFiles (с версии 3.0.1)

DeleteDirFiles
==============

Включить вкладки

Описание и параметры

Смотрите также

Примеры использования

### Описание и параметры

```
DeleteDirFiles(
	string frDir,
	string toDir,
	array arExept  = array()
);Копировать
```

Удаляет из каталога все файлы, которые содержатся в другом каталоге. Функция не работает рекурсивно.

#### Параметры функции

| Параметр | Описание | С версии |
| --- | --- | --- |
| *frDir* | Абсолютный путь к каталогу, файлы которого проверяются на наличие в каталоге, задаваемом в параметре *toDir*. |  |
| *toDir* | Абсолютный путь к каталогу, в котором будут удалены файлы с именами, найденными в каталоге, задаваемом в параметре *frDir*. |  |
| *arExept* | Массив исключений. Содержит краткие имена файлов, которые не будут удалены. | 3.1.6 |

### Смотрите также

* [DeleteDirFilesEx](/api_help/main/functions/file/deletedirfilesex.php)
* [CFile::Delete](/api_help/main/reference/cfile/delete.php)

### Примеры использования

```
<?
// удалим из папки /temp1/ все файлы, которые есть в папке /temp2/, 
// за исключением файла index.php
DeleteDirFiles(
	$_SERVER["DOCUMENT_ROOT"]."/temp2", 
	$_SERVER["DOCUMENT_ROOT"]."/temp1", 
	array("index.php")
);
?>Копировать
```

Новинки документации в соцсетях:
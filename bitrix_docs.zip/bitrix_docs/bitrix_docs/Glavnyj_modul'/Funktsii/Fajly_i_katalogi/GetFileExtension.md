[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

GetFileExtension (с версии 3.0.14)

GetFileExtension
================

```
function
GetFileExtension(
	path
);Копировать
```

По заданному пути к файлу *path* возвращает расширение файла.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| path | Путь к файлу |

#### Возвращаемое значение

Фактически, функция возвращает символы после последней точки в строке.

Новинки документации в соцсетях:
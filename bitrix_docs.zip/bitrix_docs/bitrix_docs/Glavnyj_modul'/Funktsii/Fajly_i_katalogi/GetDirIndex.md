[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

GetDirIndex (с версии 3.0.1)

GetDirIndex
===========

Включить вкладки

Описание и параметры

Смотрите также

### Описание и параметры

```
string
GetDirIndex(
	string path,
	string DirIndex = false
);Копировать
```

Возвращает имя индексного файла каталога.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *path* | Путь к каталогу относительно корня для которого необходимо определить индексный файл. |
| *DirIndex* | Разделенные пробелом возможные имена индексных файлов в порядке убывания приоритета. Для корректной работы функции в данный параметр необходимо передавать значение из поля DirectoryIndex настроек веб-сервера Apache, для IIS данный параметр можно найти в свойствах сайта, закладка "Documents" -> "Enable default content page". Необязательный параметр. По умолчанию - "false" (значение будет взято из константы DIRECTORY\_INDEX, если константа не определена, то будет взято значение по умолчанию - "**index.php index.html index.htm index.phtml default.html index.php3**"). |

Алгоритм определения индексного файла каталога следующий:

1. Берется значение из параметра *index*. Если параметр не задан, то берется значение константы DIRECTORY\_INDEX (данную константу можно определить в файле **/bitrix/php\_interface/dbconn.php** или в файлах **/bitrix/php\_interface/***ID сайта***/init.php**). Если значение константы не задано, то берется значение по умолчанию - "**index.php index.html index.htm index.phtml default.html index.php3**"
2. Полученное значение разбивается по пробелу на отдельные имена файлов
3. Каждый полученный файл проверяется на физическое существование в каталоге.
4. Первый найденный файл будет считаться индексной страницей каталога

### Смотрите также

* [GetPagePath](/api_help/main/functions/file/getpagepath.php)
* [CMain::GetCurPage](/api_help/main/reference/cmain/getcurpage.php)
* [CMain::GetCurPageParam](/api_help/main/reference/cmain/getcurpageparam.php)
* [CMain::GetCurUri](/api_help/main/reference/cmain/getcururi.php)

Новинки документации в соцсетях:
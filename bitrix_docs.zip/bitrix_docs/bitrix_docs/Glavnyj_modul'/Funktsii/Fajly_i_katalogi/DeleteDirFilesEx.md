[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

DeleteDirFilesEx (с версии 3.0.1)

DeleteDirFilesEx
================

```
bool
DeleteDirFilesEx(
	string path
);Копировать
```

Удаляет рекурсивно указанный каталог (файл). Возвращает "true" в случае успешного выполнения.

Аналог функции вновом ядре: [Bitrix\Main\IO\Directory::deleteDirectory](http://dev.1c-bitrix.ru/api_d7/bitrix/main/io/directory/deletedirectory.php).

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *path* | Путь относительно корня сайта к удаляемому каталогу (файлу). |

#### Смотрите также

* [DeleteDirFiles](/api_help/main/functions/file/deletedirfiles.php)
* [CFile::Delete](/api_help/main/reference/cfile/delete.php)

#### Примеры использования

```
<?
// удалим каталог /temp1/ и все что в нем находится
DeleteDirFilesEx("/temp1");
?>Копировать
```

Новинки документации в соцсетях:
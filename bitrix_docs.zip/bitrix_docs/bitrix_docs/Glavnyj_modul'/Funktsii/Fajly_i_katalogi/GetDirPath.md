[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

GetDirPath (с версии 3.0.3)

GetDirPath
==========

```
string
GetDirPath(
	string path
);Копировать
```

Возвращает каталог файла по пути к этому файлу.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| *path* | Путь к файлу. |

#### Смотрите также

* [CMain::GetCurDir](/api_help/main/reference/cmain/getcurdir.php)

#### Примеры использования

```
<?
echo GetDirPath("/temp1/data/file.php");
// выводит строку "/temp1/data/"
?>Копировать
```

Новинки документации в соцсетях:
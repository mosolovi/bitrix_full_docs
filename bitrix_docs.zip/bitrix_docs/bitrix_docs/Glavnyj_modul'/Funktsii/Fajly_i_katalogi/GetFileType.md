[Главный модуль](/api_help/main/index.php)

[Функции](/api_help/main/functions/index.php)

[Файлы и каталоги](/api_help/main/functions/file/index.php)

GetFileType (с версии 3.0.14)

GetFileType
===========

```
function 
GetFileType(
	path
);Копировать
```

По заданному пути к файлу возвращает его тип:

* **IMAGE** для jpg, jpeg, gif, bmp, png;
* **FLASH** для swf;
* **SOURCE** для html, htm, asp, aspx, phtml, php, php3, php4, php5, php6, shtml, sql, txt, inc, js, vbs, tpl, css, shtm;
* **UNKNOWN** для остальных.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| path | Путь к файлу |

Новинки документации в соцсетях:
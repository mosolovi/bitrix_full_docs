[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

CAdminNotify (с версии 11.5.6)

CAdminNotify
============

**CAdminNotify** - класс для работы с системными уведомлениями.

Администратор увидит стикер под панелью инструментов, как в административном интерфейсе, так и в публичной части. Уведомления есть двух типов: первые администратор может закрыть, вторые уйдут только после выполнения действия (например полной конвертации). Конкурентные объявления висят друг под другом.

#### Методы класса

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/main/reference/cadminnotify/add.php) | Добавление уведомления. |  |
| [Delete](/api_help/main/reference/cadminnotify/delete.php) | Удаление по идентификатору. |  |
| [DeleteByModule](/api_help/main/reference/cadminnotify/deletebymodule.php) | Удаление по модулю. |  |
| [DeleteByTag](/api_help/main/reference/cadminnotify/deletebytag.php) | Удаление по тегу. |  |
| [GetList](/api_help/main/reference/cadminnotify/getlist.php) | Выборка уведомлений. |  |

Новинки документации в соцсетях:
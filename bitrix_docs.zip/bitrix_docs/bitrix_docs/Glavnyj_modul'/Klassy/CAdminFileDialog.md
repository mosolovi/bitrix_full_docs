[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminFileDialog](/api_help/main/reference/cadminfiledialog/index.php)

Класс CAdminFileDialog (6.0.2)

Класс CAdminFileDialog
======================

**CAdminFileDialog** - класс для работы с файловым диалогом в административной части системы

#### Методы класса

| Метод | Описание | С версии |
| --- | --- | --- |
| [ShowScript](/api_help/main/reference/cadminfiledialog/showscript.php) | Генерирует и добавляет скрипты, необходимые для показа диалога. |  |

Новинки документации в соцсетях:
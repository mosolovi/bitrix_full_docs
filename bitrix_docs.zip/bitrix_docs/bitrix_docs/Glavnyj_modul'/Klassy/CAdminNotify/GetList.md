[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminNotify](/api_help/main/reference/cadminnotify/index.php)

GetList (с версии 11.5.6)

GetList
=======

```
CAdminNotify::GetList(
	$arSort=array(),
	$arFilter=array()
);Копировать
```

Метод производит выборку уведомлений с сортировкой и фильтрацией. Статический метод.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| arSort | Сортировка осуществляется по:  * **ID** - идентификатору сообщения; * **MODULE\_ID** - идентификатору модуля, к которому относится сообщение. |
| arFilter | Фильтрация осуществляется по:  * **ID** - идентификатору сообщения; * **MODULE\_ID** - идентификатору модуля, к которому относится сообщение; * **TAG** - тегу; * **ENABLE\_CLOSE**- разрешению на ручное закрытие. |

#### Возвращаемое значение

Возвращается экземпляр класса [CDBResult](/api_help/main/reference/cdbresult/index.php) для дальней обработки.

#### Смотрите также

* [CDBResult](/api_help/main/reference/cdbresult/index.php)

#### Примеры использования

```
CAdminNotify::GetList(array('ID' => 'DESC'), array('MODULE_ID'=>'main'));Копировать
```

Новинки документации в соцсетях:
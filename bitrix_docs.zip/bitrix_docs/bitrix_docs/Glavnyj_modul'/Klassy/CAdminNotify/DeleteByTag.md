[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminNotify](/api_help/main/reference/cadminnotify/index.php)

DeleteByTag (с версии 11.5.6)

DeleteByTag
===========

```
CAdminNotify::DeleteByTag(
	tag,
);Копировать
```

Метод удаляет уведомление по тегу. Статический метод.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| tag | Идентификатор тега |

#### Возвращаемое значение

Возвращает *true*, если удаление совершено, в противном случае - *false*.

#### Примеры использования

```
CAdminNotify::DeleteByTag("IM_CONVERT")Копировать
```

Новинки документации в соцсетях:
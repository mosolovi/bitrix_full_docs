[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminNotify](/api_help/main/reference/cadminnotify/index.php)

DeleteByModule (с версии 11.5.6)

DeleteByModule
==============

```
CAdminNotify::DeleteByModule(
	moduleId,
);Копировать
```

Метод удаляет уведомление по идентификатору модуля. Статический метод.

#### Параметры функции

| Параметр | Описание |
| --- | --- |
| moduleId | Идентификатор модуля |

#### Возвращаемое значение

Возвращает *true*, если удаление совершено, в противном случае - *false*.

#### Примеры использования

```
CAdminNotify::DeleteByModule("xmpp")Копировать
```

Новинки документации в соцсетях:
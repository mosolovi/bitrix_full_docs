[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminPage](/api_help/main/reference/cadminpage/index.php)

ShowPopupCSS (7.0.0)

ShowPopupCSS
============

```
CadminPage::ShowPopupCSS(
   )
 Копировать
```

Нестатический метод. Без параметров.

Новинки документации в соцсетях:
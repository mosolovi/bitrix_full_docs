[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminPage](/api_help/main/reference/cadminpage/index.php)

ShowCSS (создан ранее 8.6.0)

ShowCSS
=======

```
CadminPage::ShowCSS(
   )
 Копировать
```

Нестатический метод. Без параметров.

Новинки документации в соцсетях:
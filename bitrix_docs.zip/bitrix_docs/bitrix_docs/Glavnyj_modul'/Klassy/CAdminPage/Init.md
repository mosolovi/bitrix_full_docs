[Главный модуль](/api_help/main/index.php)

[Классы](/api_help/main/reference/index.php)

[CAdminPage](/api_help/main/reference/cadminpage/index.php)

Init (5.0.0)

Init
====

```
CadminPage::Init(
   )
 Копировать
```

Нестатический метод. Без параметров.

Новинки документации в соцсетях:
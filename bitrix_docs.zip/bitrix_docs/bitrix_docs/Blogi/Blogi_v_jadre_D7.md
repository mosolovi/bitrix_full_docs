[Блоги](/api_help/blogs/index.php)

Блоги в ядре D7

Блоги в ядре D7
===============

Список классов модуля **Блоги** в ядре D7

| Класс, простраство имён | Описание |
| --- | --- |
| [BlogUser](https://dev.1c-bitrix.ru/api_d7/bitrix/blog/bloguser/index.php) | Класс для работы с пользователями блога. |
| [Item](https://dev.1c-bitrix.ru/api_d7/bitrix/blog/item/index.php) | Классы для работы с записями блогов. |

Новинки документации в соцсетях:
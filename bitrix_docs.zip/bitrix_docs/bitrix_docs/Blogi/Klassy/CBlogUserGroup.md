[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogUserGroup](/api_help/blogs/classes/cblogusergroup/index.php)

Класс CBlogUserGroup (7.1.2)

Класс CBlogUserGroup
====================

**CBlogUserGroup** - класс для работы с группами пользователей блогов.

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/blogs/classes/cblogusergroup/add.php) | Добавляет новую группу пользователей блога. |  |
| [Delete](/api_help/blogs/classes/cblogusergroup/delete.php) | Удаляет группу пользователей блога. |  |
| [GetGroupPerms](/api_help/blogs/classes/cblogusergroup/getgroupperms.php) | Возвращает уровень доступа группы пользователей блога. |  |
| [GetByID](/api_help/blogs/classes/cblogusergroup/getbyid.php) | Возвращает группу пользователей блога по ее идентификатору. |  |
| [GetList](/api_help/blogs/classes/cblogusergroup/getlist.php) | Возвращает список групп пользователей блога по фильтру. |  |
| [Update](/api_help/blogs/classes/cblogusergroup/update.php) | Изменяет группу пользователей блога. |  |

Новинки документации в соцсетях:
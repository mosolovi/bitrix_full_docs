[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogCategory](/api_help/blogs/classes/cblogcategory/index.php)

Класс CBlogCategory (6.5.1)

Класс CBlogCategory
===================

**CBlogCategory** - класс для работы с категориями сообщений блога.

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/blogs/classes/cblogcategory/add.php) | Добавляет новый категорию. | 7.1.2 |
| [Delete](/api_help/blogs/classes/cblogcategory/delete.php) | Удаляет категорию. |  |
| [GetByID](/api_help/blogs/classes/cblogcategory/getbyid.php) | Возвращает категорию по ее идентификатору. |  |
| [GetList](/api_help/blogs/classes/cblogcategory/getlist.php) | Возвращает список категорий по фильтру. | 7.1.2 |
| [Update](/api_help/blogs/classes/cblogcategory/update.php) | Изменяет категорию. | 7.1.2 |

Новинки документации в соцсетях:
[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogComment](/api_help/blogs/classes/cblogcomment/index.php)

Класс CBlogComment (5.9.1)

Класс CBlogComment
==================

**CBlogComment** - класс для работы с комментариями к сообщениям блогов.

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/blogs/classes/cblogcomment/add.php) | Добавляет новый комментарий к сообщению. | 7.0.2 |
| [Delete](/api_help/blogs/classes/cblogcomment/delete.php) | Удаляет комментарий к сообщению. |  |
| [GetByID](/api_help/blogs/classes/cblogcomment/getbyid.php) | Возвращает комментарий к блогу по его идентификатору. |  |
| [GetList](/api_help/blogs/classes/cblogcomment/getlist.php) | Возвращает список комментариев по фильтру. | 7.0.2 |
| [Update](/api_help/blogs/classes/cblogcomment/update.php) | Изменяет комментарий к сообщению. | 7.0.2 |

Новинки документации в соцсетях:
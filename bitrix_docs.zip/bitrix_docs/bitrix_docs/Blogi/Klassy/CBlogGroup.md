[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogGroup](/api_help/blogs/classes/cbloggroup/index.php)

Класс CBlogGroup (7.1.2)

Класс CBlogGroup
================

**CBlogGroup** - класс для работы с группами блогов.

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/blogs/classes/cbloggroup/add.php) | Добавляет новую группу. |  |
| [Delete](/api_help/blogs/classes/cbloggroup/delete.php) | Удаляет группу. |  |
| [GetByID](/api_help/blogs/classes/cbloggroup/getbyid.php) | Возвращает группу по ее идентификатору. |  |
| [GetList](/api_help/blogs/classes/cbloggroup/getlist.php) | Возвращает список групп по фильтру. |  |
| [Update](/api_help/blogs/classes/cbloggroup/update.php) | Изменяет группу. |  |

Новинки документации в соцсетях:
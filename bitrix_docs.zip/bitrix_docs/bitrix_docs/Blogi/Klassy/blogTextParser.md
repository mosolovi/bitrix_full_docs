[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[blogTextParser](/api_help/blogs/classes/blogtextparser/index.php)

Класс blogTextParser (5.0.2)

Класс blogTextParser
====================

**blogTextParser** - класс, предназначенный для форматирования сообщений и комментариев блогов. Осуществляет замену спецсимволов и заказных тегов на реальные HTML-теги, обработку ссылок, отображение смайлов и изображений.

#### Методы класса

| Метод | Описание | С версии |
| --- | --- | --- |
| [convert](/api_help/blogs/classes/blogtextparser/convert.php) | Функция форматирования сообщения. |  |

Новинки документации в соцсетях:
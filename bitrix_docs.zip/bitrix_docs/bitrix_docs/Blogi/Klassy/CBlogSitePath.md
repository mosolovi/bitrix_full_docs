[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogSitePath](/api_help/blogs/classes/cblogsitepath/index.php)

Класс CBlogSitePath (5.9.1)

Класс CBlogSitePath
===================

**CBlogSitePath** - класс для работы с путями к публичной части блогов.

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/blogs/classes/cblogsitepath/add.php) | Добавляет новый путь. |  |
| [Delete](/api_help/blogs/classes/cblogsitepath/delete.php) | Удаляет путь. |  |
| [GetByID](/api_help/blogs/classes/cblogsitepath/getbyid.php) | Возвращает путь по его идентификатору. |  |
| [GetBySiteID](/api_help/blogs/classes/cblogsitepath/getbysiteid.php) | Возвращает путь по идентификатору сайта. |  |
| [GetList](/api_help/blogs/classes/cblogsitepath/getlist.php) | Возвращает список путей по фильтру. |  |
| [Update](/api_help/blogs/classes/cblogsitepath/update.php) | Изменяет путь. |  |

Новинки документации в соцсетях:
[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogTrackback](/api_help/blogs/classes/cblogtrackback/index.php)

Класс CBlogTrackback (5.9.0)

Класс CBlogTrackback
====================

**CBlogTrackback** - класс для работы с Trackback к сообщениям.

|  |  |
| --- | --- |
| [GetPing](/api_help/blogs/classes/cblogtrackback/getping.php) | Принимает Trackback-запросы. |
| [SendPing](/api_help/blogs/classes/cblogtrackback/sendping.php) | Отправляет Trackback-запрос по заданным адресам. |

Новинки документации в соцсетях:
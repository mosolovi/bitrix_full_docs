[Блоги](/api_help/blogs/index.php)

[Классы](/api_help/blogs/classes/index.php)

[CBlogCandidate](/api_help/blogs/classes/cblogcandidate/index.php)

Класс CBlogCandidate (7.1.2)

Класс CBlogCandidate
====================

**CBlogCandidate** - класс для работы со списком пользователей, желающих вступить в друзья блога.

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/blogs/classes/cblogcandidate/add.php) | Добавляет пользователя в список желающих вступить в друзья блога. |  |
| [Delete](/api_help/blogs/classes/cblogcandidate/delete.php) | Удаляет желающего вступить в друзья блога. |  |
| [GetByID](/api_help/blogs/classes/cblogcandidate/getbyid.php) | Возвращает информацию о пользователе, желающем вступить в друзья блога, по его идентификатору. |  |
| [GetList](/api_help/blogs/classes/cblogcandidate/getlist.php) | Возвращает список пользователей, желающих вступить в друзья блога. |  |

Новинки документации в соцсетях:
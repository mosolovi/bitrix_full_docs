[CRM](/api_help/crm/index.php)

Классы

Классы
======

#### Классы

| Класс | Описание | С версии |
| --- | --- | --- |
| [CCrmActivity](/api_help/crm/classes/crm_activity/index.php) | Класс для работы с Моими Делами. | 12.0.2 |

Новинки документации в соцсетях:
[CRM](/api_help/crm/index.php)

Константы

Константы
=========

| Константа | Проверяется | С версии |
| --- | --- | --- |
| ADMIN\_SECTION | CCrmWebDavHelper::SaveEmailAttachment | 12.0.4 |
| BX\_UTF | CCrmExternalSaleProxy::RequestToString | 11.5.0 |
| CRM\_ERROR\_LOG | CCrmExternalSaleImport::AddMessage2Log | 11.5.0 |
| LANG\_CHARSET | CCrmActivityEmailSender::TrySendEmail | 12.5.9 |

Новинки документации в соцсетях:
[CRM](/api_help/crm/index.php)

[Классы](/api_help/crm/classes/index.php)

CCRMActivity (доступен с 12.0.2)

CCRMActivity
============

#### Методы класса

| Метод | Описание | С версии |
| --- | --- | --- |
| [Add](/api_help/crm/classes/crm_activity/add.php) | Метод добавляет Дело. |  |
| [SaveCommunications](/api_help/crm/classes/crm_activity/Save_Communications.php) | Метод сохраняет связи Дела. |  |

Новинки документации в соцсетях:
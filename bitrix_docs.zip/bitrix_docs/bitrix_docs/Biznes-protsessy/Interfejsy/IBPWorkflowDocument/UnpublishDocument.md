[Бизнес-процессы](/api_help/bizproc/index.php)

[Интерфейсы](/api_help/bizproc/interface/index.php)

[IBPWorkflowDocument](/api_help/bizproc/interface/IBPWorkflowDocument/index.php)

UnpublishDocument

UnpublishDocument
=================

```
void
IBPWorkflowDocument::UnpublishDocument(
	mixed documentId
);Копировать
```

Метод снимает документ с публикации, то есть делает его недоступным в публичной части сайта.

#### Параметры метода

| Параметр | Описание |
| --- | --- |
| *documentId* | Код документа |

Новинки документации в соцсетях:
[Бизнес-процессы](/api_help/bizproc/index.php)

[Интерфейсы](/api_help/bizproc/interface/index.php)

[IBPWorkflowDocument](/api_help/bizproc/interface/IBPWorkflowDocument/index.php)

PublishDocument

PublishDocument
===============

```
void
IBPWorkflowDocument::PublishDocument(
	mixed documentId
);Копировать
```

Метод публикует документ, то есть делает его доступным в публичной части сайта.

#### Параметры метода

| Параметр | Описание |
| --- | --- |
| *documentId* | Код документа |

Новинки документации в соцсетях:
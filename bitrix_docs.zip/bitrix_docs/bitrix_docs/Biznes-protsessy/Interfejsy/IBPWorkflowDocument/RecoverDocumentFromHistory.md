[Бизнес-процессы](/api_help/bizproc/index.php)

[Интерфейсы](/api_help/bizproc/interface/index.php)

[IBPWorkflowDocument](/api_help/bizproc/interface/IBPWorkflowDocument/index.php)

RecoverDocumentFromHistory

RecoverDocumentFromHistory
==========================

```
array
IBPWorkflowDocument::RecoverDocumentFromHistory(
	mixed documentId,
	array arDocument
);Копировать
```

Метод восстанавливает указанный документ из массива. Массив создается методом [GetDocumentForHistory](/api_help/bizproc/interface/IBPWorkflowDocument/GetDocumentForHistory.php).

#### Параметры метода

| Параметр | Описание |
| --- | --- |
| *documentId* | Код документа |
| *arDocument* | Массив документа |

Новинки документации в соцсетях:
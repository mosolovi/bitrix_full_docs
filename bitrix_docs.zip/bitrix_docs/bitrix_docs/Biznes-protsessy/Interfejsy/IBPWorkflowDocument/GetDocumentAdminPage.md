[Бизнес-процессы](/api_help/bizproc/index.php)

[Интерфейсы](/api_help/bizproc/interface/index.php)

[IBPWorkflowDocument](/api_help/bizproc/interface/IBPWorkflowDocument/index.php)

GetDocumentAdminPage

GetDocumentAdminPage
====================

```
string
IBPWorkflowDocument::GetDocumentAdminPage(
	mixed documentId
);Копировать
```

Метод по коду документа возвращает ссылку на страницу документа в административной части.

#### Параметры метода

| Параметр | Описание |
| --- | --- |
| *documentId* | Код документа |

Новинки документации в соцсетях:
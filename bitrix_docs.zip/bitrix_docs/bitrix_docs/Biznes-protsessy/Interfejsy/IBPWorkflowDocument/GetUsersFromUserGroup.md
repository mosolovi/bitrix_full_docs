[Бизнес-процессы](/api_help/bizproc/index.php)

[Интерфейсы](/api_help/bizproc/interface/index.php)

[IBPWorkflowDocument](/api_help/bizproc/interface/IBPWorkflowDocument/index.php)

GetUsersFromUserGroup

GetUsersFromUserGroup
=====================

```
array
IBPWorkflowDocument::GetUsersFromUserGroup(
	mixed group,
	mixed documentId
);Копировать
```

Метод возвращает пользователей указанной группы для указанного документа в виде массива кодов пользователей.

#### Параметры метода

| Параметр | Описание |
| --- | --- |
| *group* | Код группы пользователей |
| *documentId* | Код документа |

Новинки документации в соцсетях:
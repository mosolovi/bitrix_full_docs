[Бизнес-процессы](/api_help/bizproc/index.php)

[Классы](/api_help/bizproc/bizproc_classes/index.php)

[CBPActivity](/api_help/bizproc/bizproc_classes/CBPActivity/index.php)

Initialize

Initialize
==========

```
public int 
CBPActivity::Initialize( void )Копировать
```

Этот метод вызывается исполняющей средой для инициализации действия, которая происходит до запуска бизнес-процесса на выполнение. Большинство действий не переопределяют этот метод. По умолчанию метод ничего не делает.

Новинки документации в соцсетях:
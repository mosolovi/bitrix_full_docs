[Бизнес-процессы](/api_help/bizproc/index.php)

[Классы](/api_help/bizproc/bizproc_classes/index.php)

[CBPActivity](/api_help/bizproc/bizproc_classes/CBPActivity/index.php)

GetWorkflowInstanceId

GetWorkflowInstanceId
=====================

```
string
CBPActivity::GetWorkflowInstanceId(
);Копировать
```

Метод возвращает код бизнес-процесса.

#### Возвращаемое значение

Строка, содержащая идентификатор экземпляра бизнес-процесса.

#### Смотрите также

* [CBPWorkflow::GetInstanceId](/api_help/bizproc/bizproc_classes/CBPWorkflow/GetInstanceId.php)

Новинки документации в соцсетях:
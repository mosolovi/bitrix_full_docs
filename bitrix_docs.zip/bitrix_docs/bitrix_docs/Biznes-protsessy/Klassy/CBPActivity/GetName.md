[Бизнес-процессы](/api_help/bizproc/index.php)

[Классы](/api_help/bizproc/bizproc_classes/index.php)

[CBPActivity](/api_help/bizproc/bizproc_classes/CBPActivity/index.php)

GetName

GetName
=======

```
string
CBPActivity::GetName(
);Копировать
```

Метод возвращает имя действия. Имя действия уникально в рамках бизнес-процесса.

#### Возвращаемое значение

Строка, содержащая имя действия.

Новинки документации в соцсетях:
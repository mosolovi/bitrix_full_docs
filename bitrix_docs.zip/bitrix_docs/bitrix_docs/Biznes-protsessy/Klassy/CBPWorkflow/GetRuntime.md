[Бизнес-процессы](/api_help/bizproc/index.php)

[Классы](/api_help/bizproc/bizproc_classes/index.php)

[CBPWorkflow](/api_help/bizproc/bizproc_classes/CBPWorkflow/index.php)

GetRuntime

GetRuntime
==========

```
CBPRuntime
public function CBPWorkflow::GetRuntime();Копировать
```

Метод возвращает экземпляр исполняющей среды, в которой запущен бизнес-процесс.

#### Возвращаемое значение

Возвращается объект типа CBPRuntime, представляющий собой экземпляр исполняющей среды, в которой запущен бизнес-процесс.

#### Смотрите также

* [CBPRuntime](/api_help/bizproc/bizproc_classes/CBPRuntime/index.php)

Новинки документации в соцсетях:
[Бизнес-процессы](/api_help/bizproc/index.php)

[Классы](/api_help/bizproc/bizproc_classes/index.php)

[CBPWorkflow](/api_help/bizproc/bizproc_classes/CBPWorkflow/index.php)

GetInstanceId

GetInstanceId
=============

```
string
public function GetInstanceId();Копировать
```

Метод возвращает идентификатор бизнес-процесса.

#### Смотрите также

* [CBPActivity::GetWorkflowInstanceId](/api_help/bizproc/bizproc_classes/CBPActivity/GetWorkflowInstanceId.php)

Новинки документации в соцсетях:
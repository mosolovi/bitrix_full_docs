[Бизнес-процессы](/api_help/bizproc/index.php)

[Классы](/api_help/bizproc/bizproc_classes/index.php)

[CBPWorkflow](/api_help/bizproc/bizproc_classes/CBPWorkflow/index.php)

Конструктор

Конструктор
===========

```
public function CBPWorkflow::__construct(
	string instanceId,
	CBPRuntime runtime
);Копировать
```

Конструктор создает новый экземпляр класса [CBPWorkflow](/api_help/bizproc/bizproc_classes/CBPWorkflow/index.php).

#### Параметры метода

| Параметр | Описание |
| --- | --- |
| *instanceId* | Идентификатор бизнес-процесса |
| *runtime* | Исполняющая среда |

#### Смотрите также

* [CBPRuntime](/api_help/bizproc/bizproc_classes/CBPRuntime/index.php)

Новинки документации в соцсетях:
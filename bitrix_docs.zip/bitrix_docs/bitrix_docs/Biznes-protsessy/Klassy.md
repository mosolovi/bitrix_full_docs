[Бизнес-процессы](/api_help/bizproc/index.php)

Классы

Классы
======

| Класс | Описание | С версии |
| --- | --- | --- |
| [CBPActivity](/api_help/bizproc/bizproc_classes/CBPActivity/index.php) | Основной класс. | создан ранее 8.5.3 |
| [CBPDocument](/api_help/bizproc/bizproc_classes/CBPDocument/index.php) | Вспомогательный класс, содержащий статические методы-обертки для удобного использования API модуля бизнес-процессов. | создан ранее 8.5.1 |
| [CBPRuntime](/api_help/bizproc/bizproc_classes/CBPRuntime/index.php) | Класс исполняющей среды. Он создает бизнес-процессы, а так же инфраструктуру для их исполнения. | создан ранее 8.5.4 |
| [CBPWorkflow](/api_help/bizproc/bizproc_classes/CBPWorkflow/index.php) | Класс экземпляра бизнес-процесса. Он управляет бизнес-процессом, умеет отправлять на запуск его действия, транслировать и обрабатывать события. | создан ранее 8.5.6 |

Новинки документации в соцсетях:
[Бизнес-процессы](/api_help/bizproc/index.php)

Интерфейсы

* [IBPWorkflowDocument](/api_help/bizproc/interface/IBPWorkflowDocument/index.php)